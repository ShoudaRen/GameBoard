
/* @author 
 * 2521509R
 * 2537942N
 * 2531726C
 * 2530845L
 * 2558276L
 */

package structures;
import java.util.ArrayList;
import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.basic.Card;
import structures.basic.EffectAnimation;
import structures.basic.Player;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitAnimationType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
import java.util.Random;

import com.fasterxml.jackson.databind.JsonNode;
/**
 * This class can be used to hold information about the on-going game.
 * Its created with the GameActor.
 *
 * @author Dr. Richard McCreadie
 *
 */
public class GameState {
	// 6.20
	private int turn =1;
	private Player humanPlayer;
	private Player aiPlayer;
	private int sumMana;
	private Card whichCardIchhose;
	private Tile whichTileIwantTosummon;
    private int number1=0;		
    private int number2=0;	
	private int whichCardIchoosePosition;
	private Tile whichUnitIChoose;
	// 6.28
	private int spellState;
	private Unit currentHumanUnit;
	Unit avatar1;
	Unit avatar2;
	private  Tile[][] AllTile =null; 	
	private Unit theUnitIChoose = null;
	private Tile whichTileIwantToMove;
	private ArrayList<Unit> humanUnit =new ArrayList <Unit>();
	private ArrayList<Unit> AiUnit =new ArrayList <Unit>();
	private ArrayList<Card> humanHandCard =new ArrayList <Card>(); 
	private ArrayList<Card> AiHandCard =new ArrayList <Card>(); 	
	private ArrayList<Tile>HightRed = new ArrayList<Tile>();	
	private ArrayList<Tile> summonTile =new ArrayList <Tile>(); 
	//When a card is played, add its position of int to the array, usecardPosition
	//7.10  
	private ArrayList<Integer>useCardPosition = new ArrayList<Integer>();
	private ArrayList<Integer>aiCardPosition = new ArrayList<Integer>();
	//6.25 shouda
	private ArrayList<Tile> moveTile =new ArrayList <Tile>(); 
	private ArrayList<Tile> attackTile = new ArrayList<Tile>();
	
	private Tile whichTileIwantToAttack;
	private ArrayList<Tile> attackCatchTile = new ArrayList<Tile>();
	private ArrayList<Tile> allAttackTile = new ArrayList<Tile>();
	
	private ArrayList<Tile> directAttackTile =new ArrayList <Tile>(); 
	private ArrayList<Tile> judgeAttackTile =new ArrayList <Tile>(); 
	private ArrayList<Tile> uinAttackTile=new ArrayList <Tile>();
	private ArrayList<Unit> allUnit=new ArrayList <Unit>();
	
	private ArrayList<Tile> judgeAttackTile2 =new ArrayList <Tile>(); 
	private ArrayList<Tile> moveAndAttackTile =new ArrayList <Tile>();
	private ArrayList<Tile> moveAndAttackTile2 =new ArrayList <Tile>();
	
//   7.2  
    private ArrayList<Tile> showAllEmptyTile  =new ArrayList <Tile>(); 
    private ArrayList<Tile> Flytile  =new ArrayList <Tile>(); 
    private ArrayList<Tile> showAllEmptytile2  =new ArrayList <Tile>(); 
//   7.4 zhiwen
 	private ArrayList<Card> usedCard = new ArrayList<Card>();
 	private Card []humanCard = new Card[10];
 	private Card []aiCard = new Card[10];
 	private int gameEnd =0;

	private ArrayList<Tile> aiMoveTile = new ArrayList<Tile>();
	private ArrayList<Tile> aiMoveTile2 = new ArrayList<Tile>();
	private ArrayList<Tile> aiAttackCatchTile = new ArrayList<Tile>();
	private ArrayList<Tile> aiFinalMoveTile = new ArrayList<Tile>();
	private ArrayList<Tile> aiCanAttackTile = new ArrayList<Tile>();

	private ArrayList<Unit> aiUnit2 = new ArrayList<Unit>();
	private ArrayList<Unit> humanUnit2 = new ArrayList<Unit>();
	private ArrayList<Tile> everyTile = new ArrayList<Tile>();
	
 	
	public GameState(){}

	
	Card comodo_charger = BasicObjectBuilders.loadCard(StaticConfFiles.c_comodo_charger, 0, Card.class);

	Card hailstone_golem = BasicObjectBuilders.loadCard(StaticConfFiles.c_hailstone_golem, 1, Card.class);

	Card pureblade_enforcer = BasicObjectBuilders.loadCard(StaticConfFiles.c_pureblade_enforcer, 2, Card.class);

	Card azure_herald = BasicObjectBuilders.loadCard(StaticConfFiles.c_azure_herald, 3, Card.class);

	Card silverguard_knight = BasicObjectBuilders.loadCard(StaticConfFiles.c_silverguard_knight, 4, Card.class);

	Card azurite_lion = BasicObjectBuilders.loadCard(StaticConfFiles.c_azurite_lion, 5, Card.class);

	Card fire_spitter = BasicObjectBuilders.loadCard(StaticConfFiles.c_fire_spitter, 6, Card.class);

	Card ironcliff_guardian = BasicObjectBuilders.loadCard(StaticConfFiles.c_ironcliff_guardian, 7, Card.class);

	Card truestrike = BasicObjectBuilders.loadCard(StaticConfFiles.c_truestrike, 8, Card.class);

	Card sundrop_elixir = BasicObjectBuilders.loadCard(StaticConfFiles.c_sundrop_elixir, 9, Card.class);

	
	
	Card planar_scout = BasicObjectBuilders.loadCard(StaticConfFiles.c_planar_scout, 10, Card.class);

	Card rock_pulveriser = BasicObjectBuilders.loadCard(StaticConfFiles.c_rock_pulveriser, 11, Card.class);

	Card pyromancer = BasicObjectBuilders.loadCard(StaticConfFiles.c_pyromancer, 12, Card.class);

	Card bloodshard_golem = BasicObjectBuilders.loadCard(StaticConfFiles.c_bloodshard_golem, 13, Card.class);

	Card blaze_hound = BasicObjectBuilders.loadCard(StaticConfFiles.c_blaze_hound, 14, Card.class);

	Card windshrike = BasicObjectBuilders.loadCard(StaticConfFiles.c_windshrike, 15, Card.class);

	Card serpenti = BasicObjectBuilders.loadCard(StaticConfFiles.c_serpenti, 16, Card.class);

	Card staff_of_ykir = BasicObjectBuilders.loadCard(StaticConfFiles.c_staff_of_ykir, 17, Card.class);

	Card entropic_decay = BasicObjectBuilders.loadCard(StaticConfFiles.c_entropic_decay, 18, Card.class);
	Card hailstone_golemR = BasicObjectBuilders.loadCard(StaticConfFiles.c_hailstone_golem,19, Card.class);


	
	public void initilize(ActorRef out){
	
		hailstone_golemR.setCardname("Hailstone GolemR");

		
		BasicCommands.addPlayer1Notification(out, "Initializing..",100);
		AllTile = new Tile[9][5];
		for(int i=0;i<9;i++) {
			for(int m=0;m<5;m++) {
				AllTile[i][m] = BasicObjectBuilders.loadTile(i,m);
				BasicCommands.drawTile(out, AllTile[i][m], 0);
			}
		}
		try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
		humanPlayer = new Player(20, 0);
		BasicCommands.setPlayer1Health(out, humanPlayer);
		aiPlayer = new Player(20, 0);
		BasicCommands.setPlayer2Health(out, aiPlayer);
		
		//avatar
		
		
		avatar1 = BasicObjectBuilders.loadUnit(StaticConfFiles.humanAvatar, 1, Unit.class);
		EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_summon);
		BasicCommands.playEffectAnimation(out, ef, AllTile[1][2]);
		try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
		avatar1.setPositionByTile(AllTile[1][2]);
		BasicCommands.drawUnit(out, avatar1, AllTile[1][2]);
		humanUnit.add(avatar1);
		allUnit.add(avatar1);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		BasicCommands.setUnitAttack(out, avatar1, 2);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		BasicCommands.setUnitHealth(out, avatar1, 20);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		avatar1.setHealth(20);
		avatar1.setAttack(2);
		avatar1.setMaxHealth(20);
		avatar1.setId(1);
		avatar1.replaceAttackChance();
		avatar1.replaceMoveChance();		
		
		
		avatar2 = BasicObjectBuilders.loadUnit(StaticConfFiles.aiAvatar,20, Unit.class);
		EffectAnimation eff = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_summon);
		BasicCommands.playEffectAnimation(out, eff,AllTile[7][2]);
		try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
		avatar2.setPositionByTile(AllTile[7][2]);
		BasicCommands.drawUnit(out, avatar2, AllTile[7][2]);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		BasicCommands.setUnitAttack(out, avatar2, 2);//bug
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		BasicCommands.setUnitHealth(out, avatar2, 20);
		try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
		AiUnit.add(avatar2);
		allUnit.add(avatar2);
		avatar2.setHealth(20);
		avatar2.setId(20);
		avatar2.setMaxHealth(20);
		avatar2.setAttack(2);
		avatar2.replaceAttackChance();
		avatar2.replaceMoveChance();
							
		
		BasicCommands.addPlayer1Notification(out, "Turn 1",100);


		   //  set mana
			humanPlayer.setMana(2);
			BasicCommands.setPlayer1Mana(out, humanPlayer);
			try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
			aiPlayer.setMana(2);
			BasicCommands.setPlayer2Mana(out, aiPlayer);
			try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}


			//   Card initialization
			humanCard[0]=comodo_charger;
			humanCard[1]=hailstone_golem;
			humanCard[2]=pureblade_enforcer;
			humanCard[3]=azure_herald;
			humanCard[4]=silverguard_knight;
			humanCard[5]=azurite_lion;
			humanCard[6]=fire_spitter;
			humanCard[7]=ironcliff_guardian;
			humanCard[8]=truestrike;
			humanCard[9]=sundrop_elixir;
			
			aiCard[0]= planar_scout;
			aiCard[1]=rock_pulveriser;
			aiCard[2]=pyromancer;
			aiCard[3]=bloodshard_golem;
			aiCard[4]=blaze_hound;
			aiCard[5]=windshrike;
			aiCard[6]=serpenti;
			aiCard[7]=staff_of_ykir;
			aiCard[8]=entropic_decay;
			aiCard[9]=hailstone_golemR;
			
		
			drawRandom(humanCard);
			BasicCommands.drawCard(out, drawHumanOneCard(humanCard), 1, 0);
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
			BasicCommands.drawCard(out, drawHumanOneCard(humanCard), 2, 0);
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
			BasicCommands.drawCard(out, drawHumanOneCard(humanCard), 3, 0);
			try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
     
	       //  Create several hand card
		    // Ai Shuffle the deck
			drawRandom(aiCard);
			drawAiOneCard(aiCard);
			drawAiOneCard(aiCard);
			drawAiOneCard(aiCard);
	
			
	}

	
	
	public void drawRandom(Card[]card){
	  for(int i=0;i<card.length;i++){
	  int ranNum = (int)(Math.random()*card.length);
	  Card cardTemp = card[i];
	  card[i] = card[ranNum];
	  card[ranNum] = cardTemp;
	} 
	}
	

	public Card drawHumanOneCard(Card[]card){
		humanHandCard.add(card[number1]);
		return card[number1++]; //can not flush game more than three times
	}
	
	
	public void surplusHandCard(GameState gameState){
		if(humanHandCard.size()==6){
		    number1++;
		}

		
		
	}
	
	// Ai draw card
	public Card drawAiOneCard(Card[]card){
		AiHandCard.add(card[number2]);
		return card[number2++]; 
	}
	public void surplusAIHandCard(GameState gameState){
		if(AiHandCard.size()==6){
		    number2++;
		}

	}
	
	
	
	public int getHumanHandCardNum() {
		return humanHandCard.size();
	}
	public int getaiHandCardNum() {
		return AiHandCard.size();
	}
	
	//show deployment range
			public void showSummonRange(ActorRef out,ArrayList<Unit> Unit) {
				for(Unit unitOnBoard :Unit) {
					//get the positon first
					int x=unitOnBoard.getPosition().getTilex();
					int y=unitOnBoard.getPosition().getTiley();
					
					if(x+1<9&&y<5&&x+1>=0&&y>=0) {
						BasicCommands.drawTile(out, AllTile[x+1][y], 1);
						this.getSummonTile().add(AllTile[x+1][y]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x-1<9&&y<5&&x-1>=0&&y>=0) {
						BasicCommands.drawTile(out, AllTile[x-1][y], 1);
						this.getSummonTile().add(AllTile[x-1][y]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x<9&&y+1<5&&x>=0&&y+1>=0) {
						BasicCommands.drawTile(out, AllTile[x][y+1], 1);
						this.getSummonTile().add(AllTile[x][y+1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x<9&&y-1<5&&x>=0&&y-1>=0) {
						BasicCommands.drawTile(out, AllTile[x][y-1], 1);
						this.getSummonTile().add(AllTile[x][y-1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x+1<9&&y+1<5&&x+1>=0&&y+1>=0) {
						BasicCommands.drawTile(out, AllTile[x+1][y+1], 1);
						this.getSummonTile().add( AllTile[x+1][y+1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x+1<9&&y-1<5&&x+1>=0&&y-1>=0) {
						BasicCommands.drawTile(out, AllTile[x+1][y-1], 1);
						this.getSummonTile().add(AllTile[x+1][y-1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x-1<9&&y+1<5&&x-1>=0&&y+1>=0) {
						BasicCommands.drawTile(out, AllTile[x-1][y+1], 1);
						this.getSummonTile().add(AllTile[x-1][y+1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
					if(x-1<9&&y-1<5&&x-1>=0&&y-1>=0) {
						BasicCommands.drawTile(out, AllTile[x-1][y-1], 1);
						this.getSummonTile().add(AllTile[x-1][y-1]);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
									
					// traverse, so that all units are non highlighted
					for(Unit u : allUnit) {
						int a=u.getPosition().getTilex();
						int b=u.getPosition().getTiley();
						
						BasicCommands.drawTile(out,AllTile[a][b], 0);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
				}
		    }


	
			public void showHightRed(ActorRef out,ArrayList<Unit> Unit) {
				for(Unit unit : Unit) {
					int x =unit.getPosition().getTilex();
					int y =unit.getPosition().getTiley();
					BasicCommands.drawTile(out, this.getAllTile()[x][y], 2);
					this.getHightRed().add(this.getAllTile()[x][y]);
				}
			}
			
			//Clear the deployment area and return all highlighted items to their original state
			public void clearSummonRange(ActorRef out) {
				for(Tile hightTile : this.getSummonTile()) {
					BasicCommands.drawTile(out,hightTile, 0);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				}
				this.getSummonTile().clear();
				
			
			}
			public void clearHightRed(ActorRef out) {
				for(Tile redHight : this.getHightRed()) {
					BasicCommands.drawTile(out,redHight, 0);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				}
				this.getHightRed().clear();
				
			}

			//A method to clear all states
			public void superClear(ActorRef out, GameState gameState) {
			
				for(int i=0;i<gameState.getHumanHandCard().size();i++) {
					   BasicCommands.drawCard(out,gameState.getHumanHandCard().get(i), i+1, 0);
					   gameState.clearSummonRange(out);
					   gameState.clearHightRed(out);
					   gameState.clearAllemptyTileHight(out);
					  
					  }
			}
	
			public void summonAaimation (ActorRef out, GameState gameState) {
				EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_summon);
				BasicCommands.playEffectAnimation(out, ef, gameState.getWhichTileIwantTosummon());
				try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
			}
			

	
	public Card[] getHumanCard() {

		return humanCard;
	}
	public Card[] getaiCard() {

		return aiCard;
	}

	public int getTurn() {
		return turn;
	}
	public void setTurn(int turn) {
		this.turn = turn;
	}

	public Player getHumanPlayer() {
		return humanPlayer;
	}


	public void setHumanPlayer(Player humanPlayer) {
		this.humanPlayer = humanPlayer;
	}


	public Player getAiPlayer() {
		return aiPlayer;
	}


	public void setAiPlayer(Player aiPlayer) {
		this.aiPlayer = aiPlayer;
	}


	public int getSumMana() {
		return sumMana;
	}


	public void setSumMana(int sumMana) {
		this.sumMana = sumMana;
	}
	
	public ArrayList<Unit> getHumanUnit() {
		return humanUnit;
	}



	public void setHumanUnit(ArrayList<Unit> humanUnit) {
		this.humanUnit = humanUnit;
	}



	public ArrayList<Unit> getAiUnit() {
		return AiUnit;
	}



	public void setAiUnit(ArrayList<Unit> aiUnit) {
		AiUnit = aiUnit;
	}



	public Card getWhichCardIchhose() {
		return whichCardIchhose;
	}



	public void setWhichCardIchhose(Card whichCardIchhose) {
		this.whichCardIchhose = whichCardIchhose;
	}



	public Tile getWhichTileIwantTosummon() {
		return whichTileIwantTosummon;
	}

	public ArrayList<Tile> getSummonTile() {
		return summonTile;
	}
	

	public void setSummonTile(ArrayList<Tile> summonTile) {
		this.summonTile = summonTile;
	}
		
	
	public void setWhichTileIwantTosummon(Tile whichTileIwantTosummon) {
		this.whichTileIwantTosummon = whichTileIwantTosummon;
	}
				
	
	public int getWhichCardIchoosePosition() {
		return whichCardIchoosePosition;
	}
	
	
	
	
	public void setWhichCardIchoosePosition(int whichCardIchoosePosition) {
		this.whichCardIchoosePosition = whichCardIchoosePosition;
	}

	
	
	
	public Tile getWhichUnitIChoose() {
		return whichUnitIChoose;
	}
	
	
	
	
	public void setWhichUnitIChoose(Tile whichUnitIChoose) {
		this.whichUnitIChoose = whichUnitIChoose;
	}
	

	public Unit getCurrentHumanUnit() {
		return currentHumanUnit;
	}
	
	public ArrayList<Integer> getUseCardPosition() {
		return useCardPosition;
	}
	
	
	public ArrayList<Integer> getAiCardPosition() {
		return aiCardPosition;
	}




	public Tile[][] getAllTile() {
		return AllTile;
	}

	public void setAllTile(Tile[][] allTile) {
		AllTile = allTile;
	}

	public ArrayList<Tile> getHightRed() {
		return HightRed;
	}

	public void setHightRed(ArrayList<Tile> hightRed) {
		HightRed = hightRed;
	}

	
	public ArrayList<Card> getHumanHandCard() {
		return humanHandCard;
	}


	public void setHumanHandCard(ArrayList<Card> humanHandCard) {
		this.humanHandCard = humanHandCard;
	}
	
	//@XichunNing XiaoyuanChen	
		public void moveTileHighlight(ActorRef out, GameState gameState, JsonNode message) {
		int tilex = message.get("tilex").asInt();
		int tiley = message.get("tiley").asInt();
		
	
		
		for(int k=0; k<humanUnit.size();k++) {
			int x = humanUnit.get(k).getPosition().getTilex();
			int y = humanUnit.get(k).getPosition().getTiley();

		
			if(x==tilex && y==tiley) {
				clearAttackRange(out);
				clearMoveRange(out);				
				//get the move and attack range of the unit that can move and attack  
				if(getHumanUnit().get(k).getMoveChance()>0&&getHumanUnit().get(k).getAttackChance()>0) {
				int x1 = x-2;
				int x2 = x-1;
				int x3 = x;
				int x4 = x+1;
				int x5 = x+2;
				int y1 = y-2;
				int y2 = y-1;
				int y3 = y;
				int y4 = y+1;
				int y5 = y+2;
				setLastUnitIChoose(getHumanUnit().get(k));

				if(x1<0) {
					x1=x5;
				}
				if(x2<0) {
					x1=x5;
					x2=x4;
				}
				if(x4>8) {
					x4=x2;
					x5=x1;
				}
				if(x5>8) {
					x5=x1;
				}
				if(y1<0) {
					y1=y5;
				}
				if(y2<0) {
					y1=y5;
					y2=y4;
				}
				if(y4>4) {
					y4=y2;
					y5=y1;
				}
				if(y5>4) {
					y5=y1;
				}
				
				//move range
					this.getMoveTile().add(AllTile[x2][y2]);
					if(!this.getMoveTile().contains(AllTile[x3][y2])) {
						this.getMoveTile().add(AllTile[x3][y2]);
					}
					if(!this.getMoveTile().contains(AllTile[x4][y2])) {
					this.getMoveTile().add(AllTile[x4][y2]);
					}
					if(!this.getMoveTile().contains(AllTile[x2][y3])) {
					this.getMoveTile().add(AllTile[x2][y3]);
					}
					if(!this.getMoveTile().contains(AllTile[x4][y3])) {
					this.getMoveTile().add(AllTile[x4][y3]);
					}
					if(!this.getMoveTile().contains(AllTile[x2][y4])) {
					this.getMoveTile().add(AllTile[x2][y4]);
					}
					if(!this.getMoveTile().contains(AllTile[x3][y4])) {
					this.getMoveTile().add(AllTile[x3][y4]);
					}
					if(!this.getMoveTile().contains(AllTile[x4][y4])) {
					this.getMoveTile().add(AllTile[x4][y4]);
					}
					if(!this.getMoveTile().contains(AllTile[x3][y1])) {
					this.getMoveTile().add(AllTile[x3][y1]);
					}
					if(!this.getMoveTile().contains(AllTile[x3][y5])) {
					this.getMoveTile().add(AllTile[x3][y5]);
					}
					if(!this.getMoveTile().contains(AllTile[x5][y3])) {
					this.getMoveTile().add(AllTile[x5][y3]);
					}
					if(!this.getMoveTile().contains(AllTile[x1][y3])) {
					this.getMoveTile().add(AllTile[x1][y3]);
					}
				
					
				//same as move range for loop in the attack function	
					this.getAllAttackTile().add(AllTile[x2][y2]);
					if(!this.getAllAttackTile().contains(AllTile[x3][y2])) {
						this.getAllAttackTile().add(AllTile[x3][y2]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x4][y2])) {
					this.getAllAttackTile().add(AllTile[x4][y2]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x2][y3])) {
					this.getAllAttackTile().add(AllTile[x2][y3]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x4][y3])) {
					this.getAllAttackTile().add(AllTile[x4][y3]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x2][y4])) {
					this.getAllAttackTile().add(AllTile[x2][y4]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x3][y4])) {
					this.getAllAttackTile().add(AllTile[x3][y4]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x4][y4])) {
					this.getAllAttackTile().add(AllTile[x4][y4]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x3][y1])) {
					this.getAllAttackTile().add(AllTile[x3][y1]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x3][y5])) {
					this.getAllAttackTile().add(AllTile[x3][y5]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x5][y3])) {
					this.getAllAttackTile().add(AllTile[x5][y3]);
					}
					if(!this.getAllAttackTile().contains(AllTile[x1][y3])) {
					this.getAllAttackTile().add(AllTile[x1][y3]);
					}
					
				
					
				//direct-attack range without moving	
					this.getDirectAttackTile().add(AllTile[x2][y2]);
					if(!this.getDirectAttackTile().contains(AllTile[x3][y2])) {
						this.getDirectAttackTile().add(AllTile[x3][y2]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x4][y2])) {
					this.getDirectAttackTile().add(AllTile[x4][y2]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x2][y3])) {
					this.getDirectAttackTile().add(AllTile[x2][y3]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x4][y3])) {
					this.getDirectAttackTile().add(AllTile[x4][y3]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x2][y4])) {
					this.getDirectAttackTile().add(AllTile[x2][y4]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x3][y4])) {
					this.getDirectAttackTile().add(AllTile[x3][y4]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[x4][y4])) {
					this.getDirectAttackTile().add(AllTile[x4][y4]);
					}
				//provoke					
					if(this.getDirectAttackTile().contains(getRock())) {
						BasicCommands.drawTile(out, getRock(), 2);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
						getAttackTile().add(getRock());
						this.getMoveTile().clear();
					}
					else {
					
				//highlight	
				BasicCommands.drawTile(out, AllTile[x2][y2], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x3][y2], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x4][y2], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x2][y3], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x4][y3], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x2][y4], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x3][y4], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x4][y4], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x3][y1], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x3][y5], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x5][y3], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.drawTile(out, AllTile[x1][y3], 1);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				
				//remove the tile that there already is unit and cancel its highlight
				for(int j=0; j<humanUnit.size();j++) {
					int a = humanUnit.get(j).getPosition().getTilex();
					int b = humanUnit.get(j).getPosition().getTiley();
					BasicCommands.drawTile(out, AllTile[a][b], 0);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					 for (int i = 0; i < 9; i++) {
				            for (int m = 0; m < 5; m++) {
				                if (AllTile[a][b].equals(AllTile[i][m])) {				                
				                		this.getMoveTile().remove(AllTile[a][b]);

				                }
				            }
					 }			
				}
				for(int j=0; j<AiUnit.size();j++) {
					int a = AiUnit.get(j).getPosition().getTilex();
					int b = AiUnit.get(j).getPosition().getTiley();
					BasicCommands.drawTile(out, AllTile[a][b], 0);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					 for (int i = 0; i < 9; i++) {
				            for (int m = 0; m < 5; m++) {
				                if (AllTile[a][b].equals(AllTile[i][m])) {				                
				                	this.getMoveTile().remove(AllTile[a][b]);
				                }
				            }
					 }			
				}
				
				attackCatchTile.addAll(allAttackTile);
				//ability:Ranged
				 if(humanUnit.get(k).getId()==7) {
					 this.getAttackCatchTile().clear();
				 }else {
				
				//get the whole range of attack after moving
				 for(int g=0; g<allAttackTile.size();g++) {
				 
					 
						int p = allAttackTile.get(g).getTilex();
						int q = allAttackTile.get(g).getTiley();

							int p1 = p-1;
							int p2 = p;
							int p3 = p+1;						
							int q1 = q-1;
							int q2 = q;
							int q3 = q+1;
							if(p1<0) {
								p1=p3;
							}
							if(p3>8) {
								p3=p1;
							}
							if(q1<0) {
								q1=q3;
							}
							if(q3>4) {
								q3=q1;
							}
							if(!this.getAttackCatchTile().contains(AllTile[p1][q2])) {
								this.getAttackCatchTile().add(AllTile[p1][q2]);
							}
 
							if(!this.getAttackCatchTile().contains(AllTile[p3][q2])) {
								this.getAttackCatchTile().add(AllTile[p3][q2]);
							}
							
							if(!this.getAttackCatchTile().contains(AllTile[p2][q1])) {
								this.getAttackCatchTile().add(AllTile[p2][q1]);
							}
							
							if(!this.getAttackCatchTile().contains(AllTile[p2][q3])) {
								this.getAttackCatchTile().add(AllTile[p2][q3]);
							}
							if(!this.getAttackCatchTile().contains(AllTile[p1][q1])) {
								this.getAttackCatchTile().add(AllTile[p1][q1]);
							}
 
							if(!this.getAttackCatchTile().contains(AllTile[p1][q3])) {
								this.getAttackCatchTile().add(AllTile[p1][q3]);
							}
							
							if(!this.getAttackCatchTile().contains(AllTile[p3][q1])) {
								this.getAttackCatchTile().add(AllTile[p3][q1]);
							}
							
							if(!this.getAttackCatchTile().contains(AllTile[p3][q3])) {
								this.getAttackCatchTile().add(AllTile[p3][q3]);
							}
				 }		
				 }
				 
				 //highlight
				 attackTileHighlight(out, gameState, message);
				 try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
			
				}
			}
				//ability:Ranged
				if(getHumanUnit().get(k).getId()==7) {					
					if(getHumanUnit().get(k).getAttackChance()>0) {
						if(this.getDirectAttackTile().contains(getRock())) {
							BasicCommands.drawTile(out, getRock(), 2);
							try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
							this.getAttackTile().add(getRock());
							this.getMoveTile().clear();
						}else {
						setLastUnitIChoose(getHumanUnit().get(k));
						
					this.getDirectAttackTile().clear();
					this.getDirectAttackTile().addAll(getEveryTile());
					for(Unit h : AiUnit) {
						for(Tile hightTile : this.getDirectAttackTile()) {
							if(h.getPosition().getTilex()==hightTile.getTilex()&&h.getPosition().getTiley()==hightTile.getTiley()) {
								BasicCommands.drawTile(out,hightTile, 2);
								if(!this.getAttackTile().contains(hightTile)) {
									this.getAttackTile().add(hightTile);
								}
								try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
							}
						}
					}	
					}	
					}	
					
				}else {
					
				//get the attack range of the unit that has already moved
				if(getHumanUnit().get(k).getMoveChance()==0&&getHumanUnit().get(k).getAttackChance()>0) {
					
					setLastUnitIChoose(getHumanUnit().get(k));
					clearMoveRange(out);
					
					
					int p1 = x-1;
					int p2 = x;
					int p3 = x+1;						
					int q1 = y-1;
					int q2 = y;
					int q3 = y+1;
					if(p1<0) {
						p1=p3;
					}
					if(p3>8) {
						p3=p1;
					}
					if(q1<0) {
						q1=q3;
					}
					if(q3>4) {
						q3=q1;
					}
					if(!this.getDirectAttackTile().contains(AllTile[p1][q2])) {
						this.getDirectAttackTile().add(AllTile[p1][q2]);
					}

					if(!this.getDirectAttackTile().contains(AllTile[p3][q2])) {
						this.getDirectAttackTile().add(AllTile[p3][q2]);
					}
					
					if(!this.getDirectAttackTile().contains(AllTile[p2][q1])) {
						this.getDirectAttackTile().add(AllTile[p2][q1]);
					}
					
					if(!this.getDirectAttackTile().contains(AllTile[p2][q3])) {
						this.getDirectAttackTile().add(AllTile[p2][q3]);
					}
					if(!this.getDirectAttackTile().contains(AllTile[p1][q1])) {
						this.getDirectAttackTile().add(AllTile[p1][q1]);
					}

					if(!this.getDirectAttackTile().contains(AllTile[p1][q3])) {
						this.getDirectAttackTile().add(AllTile[p1][q3]);
					}
					
					if(!this.getDirectAttackTile().contains(AllTile[p3][q1])) {
						this.getDirectAttackTile().add(AllTile[p3][q1]);
					}
					
					if(!this.getDirectAttackTile().contains(AllTile[p3][q3])) {
						this.getDirectAttackTile().add(AllTile[p3][q3]);
					}
					
					//provoke
					if(this.getDirectAttackTile().contains(getRock())) {
						BasicCommands.drawTile(out, getRock(), 2);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
						getAttackTile().add(getRock());
					}else {
			
					for(Unit h : AiUnit) {
						for(Tile hightTile : this.getDirectAttackTile()) {
							if(h.getPosition().getTilex()==hightTile.getTilex()&&h.getPosition().getTiley()==hightTile.getTiley()) {
								BasicCommands.drawTile(out,hightTile, 2);
								if(!this.getAttackTile().contains(hightTile)) {
									this.getAttackTile().add(hightTile);
								}
								try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
							}
						}
					}
				}
				}
			}
			
			}
		
		}
		
	}
	
		//@XichunNing XiaoyuanChen	
		public void move(ActorRef out, GameState gameState, JsonNode message) {

			
			int tilel = message.get("tilex").asInt();
			int tilem = message.get("tiley").asInt();
			
			//complete move function with arraylist moveTile
			for(Tile a : moveTile) {
				int l = a.getTilex();
				int m = a.getTiley();
				if(l==tilel && m==tilem) {


					setWhichTileIwantToMove(AllTile[l][m]);
					BasicCommands.moveUnitToTile(out, theUnitIChoose, getWhichTileIwantToMove() );
					BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.move);
					theUnitIChoose.setPositionByTile(getWhichTileIwantToMove()); 

					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					getLastUnitIChoose().deleteMoveChance();
					setLastUnitIChoose(null);
					setWhichTileIwantToMove(null);
					clearMoveRange(out);
					clearAttackRange(out);
					break;
			}
		}
			}	
	
		//clear the move range
		public void clearMoveRange(ActorRef out) {
			for(Tile hightTile : this.getMoveTile()) {
				BasicCommands.drawTile(out,hightTile, 0);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
			}
			this.getMoveTile().clear();
		}
	
	
	public ArrayList<Tile> getMoveTile() {
		return moveTile;
	}
	public void setLastUnitIChoose(Unit theUnitIChoose) {
		this.theUnitIChoose = theUnitIChoose;
	}
	public Unit getLastUnitIChoose() {
		return theUnitIChoose;
	}
	public void setWhichTileIwantToMove(Tile whichTileIwantToMove) {
		this.whichTileIwantToMove = whichTileIwantToMove;
	}
	public Tile getWhichTileIwantToMove() {
		return whichTileIwantToMove;
	}




	public int getSpellState() {
		return spellState;
	}


	public void setSpellState(int spellState) {
		this.spellState = spellState;
	}




	public void setNumber1(int number1) {
		this.number1 = number1;
	}



	public Unit getAvatar1() {
		return avatar1;
	}




	public void setAvatar1(Unit avatar1) {
		this.avatar1 = avatar1;
	}




	public Unit getAvatar2() {
		return avatar2;
	}




	public void setAvatar2(Unit avatar2) {
		this.avatar2 = avatar2;
	}




	public ArrayList<Card> getAiHandCard() {
		return AiHandCard;
	}




	public void setAiHandCard(ArrayList<Card> aiHandCard) {
		AiHandCard = aiHandCard;
	}




	public ArrayList<Unit> getAllUnit() {
		return allUnit;
	}




	public void setAllUnit(ArrayList<Unit> allUnit) {
		this.allUnit = allUnit;
	}

	
	public void attack(ActorRef out, GameState gameState, JsonNode message) {
		
		int tilel = message.get("tilex").asInt();
		int tilem = message.get("tiley").asInt();
		
		for(Tile a : attackTile) {
			int l = a.getTilex();
			int m = a.getTiley();
			if(l==tilel && m==tilem) {


				setWhichTileIwantToAttack(AllTile[l][m]);
				if(directAttackTile.contains(a)) {
						//direct attack
						//ranged
						if(theUnitIChoose.getId()==7) {
							EffectAnimation projectile = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_projectiles);
							BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.attack);
							try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
							BasicCommands.playProjectileAnimation(out, projectile, 0, AllTile[theUnitIChoose.getPosition().getTilex()][theUnitIChoose.getPosition().getTiley()], a);
						}
							
					
						BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.attack);
						try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
						BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.idle);
						//calculate health and complete counterattack
						for(Unit c : AiUnit) {
							int p = c.getPosition().getTilex();
							int q = c.getPosition().getTiley();
							if(p==l&&q==m) {
								int AiHealth = c.getHealth() - theUnitIChoose.getAttack();
								c.setHealth(AiHealth);
								BasicCommands.setUnitHealth(out, c,AiHealth); 
								
								if(AiHealth<=0) {
									BasicCommands.playUnitAnimation(out, c, UnitAnimationType.death);
									try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
									BasicCommands.deleteUnit(out, c);
									try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
									WindshrikeDie(c,out,this);
									AiUnit.remove(c);
									this.allUnit.remove(c);
								}
								//provoke
								else if( (c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==-1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==-1)||
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==0&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==-1)||	
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==-1)||
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==-1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==0)||	
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==0)||
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==-1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==1)||	
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==0&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==1)||
										(c.getPosition().getTilex()-theUnitIChoose.getPosition().getTilex()==1&&c.getPosition().getTiley()-theUnitIChoose.getPosition().getTiley()==1)) {
								

								
									BasicCommands.playUnitAnimation(out, c, UnitAnimationType.attack);
									try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
									BasicCommands.playUnitAnimation(out, c, UnitAnimationType.idle);
									int health = theUnitIChoose.getHealth() - c.getAttack();
									theUnitIChoose.setHealth(health);
									BasicCommands.setUnitHealth(out, theUnitIChoose,health); 
									try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
									
								if( health <=0) {
									BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.death);
									try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
									humanUnit.remove(theUnitIChoose);
									this.allUnit.remove(theUnitIChoose);
									BasicCommands.deleteUnit(out, theUnitIChoose);
									try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
									
								}
								if(theUnitIChoose.getId()==1) {
									for(Unit SilverKnight: getHumanUnit()) {
										if(SilverKnight.getId()==8) {
											int silverAddAttack = SilverKnight.getAttack()+2;
											SilverKnight.setAttack(silverAddAttack);
											BasicCommands.setUnitAttack(out, SilverKnight, silverAddAttack);
											try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
											break;
										}
									}
								}
								}
																								
								avatarDead (theUnitIChoose, out);
								avatarDead (c, out);
								break;	
								}				
						}						
					}					
					
					//attack with moving
					else{
							this.getMoveAndAttackTile().clear();
							this.getMoveAndAttackTile2().clear();
						// judge which tile to go to for attacking
						if((l-getLastUnitIChoose().getPosition().getTilex()==1&&m-getLastUnitIChoose().getPosition().getTiley()==-2)||
								(l-getLastUnitIChoose().getPosition().getTilex()==2&&m-getLastUnitIChoose().getPosition().getTiley()==-1)   ) {
							
							this.getMoveAndAttackTile().add(AllTile[l-1][m]);
							this.getMoveAndAttackTile().add(AllTile[l-1][m+1]);
							this.getMoveAndAttackTile().add(AllTile[l][m+1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						
					
						if((l-getLastUnitIChoose().getPosition().getTilex()==1&&m-getLastUnitIChoose().getPosition().getTiley()==2)||
								(l-getLastUnitIChoose().getPosition().getTilex()==2&&m-getLastUnitIChoose().getPosition().getTiley()==1)   ) {
							
							this.getMoveAndAttackTile().add(AllTile[l-1][m]);
							this.getMoveAndAttackTile().add(AllTile[l-1][m-1]);
							this.getMoveAndAttackTile().add(AllTile[l][m-1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==-1&&m-getLastUnitIChoose().getPosition().getTiley()==-2)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-2&&m-getLastUnitIChoose().getPosition().getTiley()==-1)   ) {
							
							this.getMoveAndAttackTile().add(AllTile[l+1][m]);
							this.getMoveAndAttackTile().add(AllTile[l+1][m+1]);
							this.getMoveAndAttackTile().add(AllTile[l][m+1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==-1&&m-getLastUnitIChoose().getPosition().getTiley()==2)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-2&&m-getLastUnitIChoose().getPosition().getTiley()==1)   ) {							
							this.getMoveAndAttackTile().add(AllTile[l+1][m]);
							this.getMoveAndAttackTile().add(AllTile[l+1][m-1]);
							this.getMoveAndAttackTile().add(AllTile[l][m-1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						if(l-getLastUnitIChoose().getPosition().getTilex()==0&&m-getLastUnitIChoose().getPosition().getTiley()==2)
						{	
							if(l-1>=0) { 
							this.getMoveAndAttackTile().add(AllTile[l-1][m-1]);}
							if(l+1<=8) { 
							this.getMoveAndAttackTile().add(AllTile[l+1][m-1]);}
							this.getMoveAndAttackTile().add(AllTile[l][m-1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						if(l-getLastUnitIChoose().getPosition().getTilex()==0&&m-getLastUnitIChoose().getPosition().getTiley()==-2) 
						{	
							if(l-1>=0) { 
							this.getMoveAndAttackTile().add(AllTile[l-1][m+1]);}
							if(l+1<=8) {
							this.getMoveAndAttackTile().add(AllTile[l+1][m+1]);}
							this.getMoveAndAttackTile().add(AllTile[l][m+1]);
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==0&&m-getLastUnitIChoose().getPosition().getTiley()==3)||
								(l-getLastUnitIChoose().getPosition().getTilex()==1&&m-getLastUnitIChoose().getPosition().getTiley()==3)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-1&&m-getLastUnitIChoose().getPosition().getTiley()==3)   ) {							
							this.getMoveAndAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()+2]);							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==0&&m-getLastUnitIChoose().getPosition().getTiley()==-3)||
								(l-getLastUnitIChoose().getPosition().getTilex()==1&&m-getLastUnitIChoose().getPosition().getTiley()==-3)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-1&&m-getLastUnitIChoose().getPosition().getTiley()==-3)   ) {							
							this.getMoveAndAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()-2]);							
						}
						
						
						
						if(l-getLastUnitIChoose().getPosition().getTilex()==2&&m-getLastUnitIChoose().getPosition().getTiley()==0) 
						{	if(m-1>=0) {						
							this.getMoveAndAttackTile().add(AllTile[l-1][m-1]);}
							this.getMoveAndAttackTile().add(AllTile[l-1][m]);
							if(m+1<=4) {
							this.getMoveAndAttackTile().add(AllTile[l-1][m+1]);}
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						if(l-getLastUnitIChoose().getPosition().getTilex()==-2&&m-getLastUnitIChoose().getPosition().getTiley()==0) 
						{	
							if(m-1>=0) {	
							this.getMoveAndAttackTile().add(AllTile[l+1][m-1]);}
							this.getMoveAndAttackTile().add(AllTile[l+1][m]);
							if(m+1<=4) {
							this.getMoveAndAttackTile().add(AllTile[l+1][m+1]);}
							for(Tile d : moveTile) {
								for(Tile e : moveAndAttackTile) {
									if (d.equals(e)) {
										this.getMoveAndAttackTile2().add(e);
									}									
								}
							}							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==3&&m-getLastUnitIChoose().getPosition().getTiley()==0)||
								(l-getLastUnitIChoose().getPosition().getTilex()==3&&m-getLastUnitIChoose().getPosition().getTiley()==-1)||
								(l-getLastUnitIChoose().getPosition().getTilex()==3&&m-getLastUnitIChoose().getPosition().getTiley()==1)   ) {							
							this.getMoveAndAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()+2][getLastUnitIChoose().getPosition().getTiley()]);							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==-3&&m-getLastUnitIChoose().getPosition().getTiley()==0)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-3&&m-getLastUnitIChoose().getPosition().getTiley()==-1)||
								(l-getLastUnitIChoose().getPosition().getTilex()==-3&&m-getLastUnitIChoose().getPosition().getTiley()==1)   ) {							
							this.getMoveAndAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()-2][getLastUnitIChoose().getPosition().getTiley()]);							
						}
						
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==2&&m-getLastUnitIChoose().getPosition().getTiley()==-2)) 
						{							
							this.getMoveAndAttackTile2().add(AllTile[l-1][m+1]);							
						}
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==2&&m-getLastUnitIChoose().getPosition().getTiley()==2)) 
						{							
							this.getMoveAndAttackTile2().add(AllTile[l-1][m-1]);							
						}
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==-2&&m-getLastUnitIChoose().getPosition().getTiley()==2)) 
						{							
							this.getMoveAndAttackTile2().add(AllTile[l+1][m-1]);							
						}
						
						if((l-getLastUnitIChoose().getPosition().getTilex()==-2&&m-getLastUnitIChoose().getPosition().getTiley()==-2)) 
						{							
							this.getMoveAndAttackTile2().add(AllTile[l+1][m+1]);							
						}
						
						for(Tile f : moveAndAttackTile2) {
								setWhichTileIwantToMove(f);
								BasicCommands.moveUnitToTile(out, theUnitIChoose, getWhichTileIwantToMove() );
								BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.move);
								theUnitIChoose.setPositionByTile(getWhichTileIwantToMove()); 
								try {Thread.sleep(2500);} catch (InterruptedException e) {e.printStackTrace();}
																
								//attack
								
								BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.attack);
								try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
								BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.idle);
								//calculate and couterattack
								for(Unit c : AiUnit) {
									int p = c.getPosition().getTilex();
									int q = c.getPosition().getTiley();
									if(p==l&&q==m) {
										int remainHealthAi = c.getHealth() - theUnitIChoose.getAttack();
										c.setHealth(remainHealthAi);
										BasicCommands.setUnitHealth(out, c, remainHealthAi); 
										try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
										
										if(c.getHealth() <=0) {
											BasicCommands.playUnitAnimation(out, c, UnitAnimationType.death);
											try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
											BasicCommands.deleteUnit(out, c);
											try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
											WindshrikeDie(c,out,this);
											AiUnit.remove(c);
											allUnit.remove(c);
										}
										else{
											BasicCommands.playUnitAnimation(out, c, UnitAnimationType.attack);
											try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
											BasicCommands.playUnitAnimation(out, c, UnitAnimationType.idle);
											int remainHealth = theUnitIChoose.getHealth() - c.getAttack();
											theUnitIChoose.setHealth(remainHealth);
											BasicCommands.setUnitHealth(out, theUnitIChoose, remainHealth); 
											try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
											
										if(theUnitIChoose.getHealth()<=0) {
											BasicCommands.playUnitAnimation(out, theUnitIChoose, UnitAnimationType.death);
											try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
											BasicCommands.deleteUnit(out, theUnitIChoose);
											try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
											humanUnit.remove(theUnitIChoose);
											allUnit.remove(theUnitIChoose);
										}
										if(theUnitIChoose.getId()==1) {
											for(Unit SilverKnight: getHumanUnit()) {
												if(SilverKnight.getId()==8) {
													int silverAddAttack3 = SilverKnight.getAttack()+2;
													SilverKnight.setAttack(silverAddAttack3);
													BasicCommands.setUnitAttack(out, SilverKnight, silverAddAttack3);
													try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
													break;
												}
											}
										}
									}
									avatarDead (theUnitIChoose, out);
									avatarDead (c, out);
								break;	
								}					
							}							
						break;
					}
				}					

				
				this.getMoveAndAttackTile2().clear();
				getLastUnitIChoose().deleteMoveChance();
				getLastUnitIChoose().deleteAttackChance();
				setLastUnitIChoose(null);
				setWhichTileIwantToAttack(null);
				clearMoveRange(out);
				clearAttackRange(out);
				break;
		}
	}
		gameState.getHumanPlayer().setHealth(getHumanUnit().get(0).getHealth());
		BasicCommands.setPlayer1Health(out,humanPlayer);
		gameState.getAiPlayer().setHealth(getAiUnit().get(0).getHealth());
		BasicCommands.setPlayer2Health(out,aiPlayer);
}
		
		//red highlight of attack 
		 public void attackTileHighlight(ActorRef out, GameState gameState, JsonNode message) {

			 
			 
			 for(int k=0;k<AiUnit.size();k++) {
				 	int x = AiUnit.get(k).getPosition().getTilex();
					int y = AiUnit.get(k).getPosition().getTiley();
					
					//judge if it can attack enemy unit with and without moving or not
					for(int i=0;i<attackCatchTile.size();i++) {
						int catchX = attackCatchTile.get(i).getTilex();
						int catchY = attackCatchTile.get(i).getTiley();
						if(catchX==x&&catchY==y) {	

							
							if((x-getLastUnitIChoose().getPosition().getTilex()==1&&y-getLastUnitIChoose().getPosition().getTiley()==-2)||
									(x-getLastUnitIChoose().getPosition().getTilex()==2&&y-getLastUnitIChoose().getPosition().getTiley()==-1)   ) {
							this.getJudgeAttackTile2().clear();
							this.getJudgeAttackTile().add(AllTile[x-1][y]);
							this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
							this.getJudgeAttackTile().add(AllTile[x][y+1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y+1]);
							}
								for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}																		
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							}


							
							if((x-getLastUnitIChoose().getPosition().getTilex()==1&&y-getLastUnitIChoose().getPosition().getTiley()==2)||
										(x-getLastUnitIChoose().getPosition().getTilex()==2&&y-getLastUnitIChoose().getPosition().getTiley()==1)) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x-1][y]);
							this.getJudgeAttackTile().add(AllTile[x-1][y-1]);
							this.getJudgeAttackTile().add(AllTile[x][y-1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y-1]);
							}	
								for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}
									
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if((x-getLastUnitIChoose().getPosition().getTilex()==-1&&y-getLastUnitIChoose().getPosition().getTiley()==-2)|
										(x-getLastUnitIChoose().getPosition().getTilex()==-2&&y-getLastUnitIChoose().getPosition().getTiley()==-1)) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x+1][y]);
							this.getJudgeAttackTile().add(AllTile[x+1][y+1]);
							this.getJudgeAttackTile().add(AllTile[x][y+1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y+1]);
							}	
								for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}																		
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if((x-getLastUnitIChoose().getPosition().getTilex()==-1&&y-getLastUnitIChoose().getPosition().getTiley()==2)|
									(x-getLastUnitIChoose().getPosition().getTilex()==-2&&y-getLastUnitIChoose().getPosition().getTiley()==1)) {		
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x+1][y]);
							this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
							this.getJudgeAttackTile().add(AllTile[x][y-1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y-1]);
							}	
								for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}																		
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}	
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==0&&y-getLastUnitIChoose().getPosition().getTiley()==2) {
								this.getJudgeAttackTile2().clear();
								if(x==0) {
									this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
									this.getJudgeAttackTile().add(AllTile[x][y-1]);	
									if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
										this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);									
									}if(!this.getJudgeAttackTile2().contains(AllTile[x][y-1])) {
									this.getJudgeAttackTile2().add(AllTile[x][y-1]);
									}
								}else if(x==8) {
									this.getJudgeAttackTile().add(AllTile[x-1][y-1]);
									this.getJudgeAttackTile().add(AllTile[x][y-1]);	
									if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
									this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x][y-1])) {
									this.getJudgeAttackTile2().add(AllTile[x][y-1]);
									}
								}else {
								
								this.getJudgeAttackTile().add(AllTile[x-1][y-1]);
							this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
							this.getJudgeAttackTile().add(AllTile[x][y-1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y-1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y-1]);
							}
								}
							for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}																		
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==0&&y-getLastUnitIChoose().getPosition().getTiley()==-2) {
								this.getJudgeAttackTile2().clear();
								if(x==0) {								
									this.getJudgeAttackTile().add(AllTile[x+1][y+1]);
									this.getJudgeAttackTile().add(AllTile[x][y+1]);	
									if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
									this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x][y+1])) {
									this.getJudgeAttackTile2().add(AllTile[x][y+1]);
									}
								}
								else if(x==8) {
									this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
									this.getJudgeAttackTile().add(AllTile[x][y+1]);	
									if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
										this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);
									}
									if(!this.getJudgeAttackTile2().contains(AllTile[x][y+1])) {
									this.getJudgeAttackTile2().add(AllTile[x][y+1]);
									}
								}
								else {
								this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
							this.getJudgeAttackTile().add(AllTile[x+1][y+1]);
							this.getJudgeAttackTile().add(AllTile[x][y+1]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
							}if(!this.getJudgeAttackTile2().contains(AllTile[x][y+1])) {
							this.getJudgeAttackTile2().add(AllTile[x][y+1]);
							}
							}	
							for(Tile d : judgeAttackTile) {
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
											this.getJudgeAttackTile2().remove(d);
											break;
										}											
									}																		
								}															
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							
							if( (x-getLastUnitIChoose().getPosition().getTilex()==0&&y-getLastUnitIChoose().getPosition().getTiley()==3)||
									(x-getLastUnitIChoose().getPosition().getTilex()==-1&&y-getLastUnitIChoose().getPosition().getTiley()==3)||
									(x-getLastUnitIChoose().getPosition().getTilex()==1&&y-getLastUnitIChoose().getPosition().getTiley()==3)) 
							{
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()+2]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()+2])) 
							{
							this.getJudgeAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()+2]);	
							}
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==getLastUnitIChoose().getPosition().getTilex()&&e.getPosition().getTiley()==getLastUnitIChoose().getPosition().getTiley()+2) {
											this.getJudgeAttackTile2().remove(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()+2]);
											break;
										}											
									}																		
																							
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[x][y])) {
								this.getAttackTile().add(AllTile[x][y]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if( (x-getLastUnitIChoose().getPosition().getTilex()==0&&y-getLastUnitIChoose().getPosition().getTiley()==-3)||
									(x-getLastUnitIChoose().getPosition().getTilex()==-1&&y-getLastUnitIChoose().getPosition().getTiley()==-3)||
									(x-getLastUnitIChoose().getPosition().getTilex()==1&&y-getLastUnitIChoose().getPosition().getTiley()==-3)
									) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()-2]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()-2])) {
							this.getJudgeAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()-2]);	
							}
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==getLastUnitIChoose().getPosition().getTilex()&&e.getPosition().getTiley()==getLastUnitIChoose().getPosition().getTiley()-2) {
											this.getJudgeAttackTile2().remove(AllTile[getLastUnitIChoose().getPosition().getTilex()][getLastUnitIChoose().getPosition().getTiley()-2]);
											break;
										}											
									}																		
																							
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[x][y])) {
								this.getAttackTile().add(AllTile[x][y]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==2&&y-getLastUnitIChoose().getPosition().getTiley()==0) {
								this.getJudgeAttackTile2().clear();
								if(y==0) {
									this.getJudgeAttackTile().add(AllTile[x-1][y]);
									this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
									if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y])) {
									this.getJudgeAttackTile2().add(AllTile[x-1][y]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
									this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);
									}	
								}
								else if(y==4) {
									this.getJudgeAttackTile().add(AllTile[x-1][y-1]);
									this.getJudgeAttackTile().add(AllTile[x-1][y]);
									if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
										this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y])) {
									this.getJudgeAttackTile2().add(AllTile[x-1][y]);
									}	
								}
								else {
								this.getJudgeAttackTile().add(AllTile[x-1][y-1]);
								this.getJudgeAttackTile().add(AllTile[x-1][y]);
								this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
								if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
									this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);
								}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y]);
								}if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);
								}	
								}
								for(Tile d : judgeAttackTile) {
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
												this.getJudgeAttackTile2().remove(d);
												break;
											}											
										}																		
									}															
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==-2&&y-getLastUnitIChoose().getPosition().getTiley()==0) {
								this.getJudgeAttackTile2().clear();
								if(y==0) {								
									this.getJudgeAttackTile().add(AllTile[x+1][y]);
									this.getJudgeAttackTile().add(AllTile[x+1][y+1]);

									if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y])) {
									this.getJudgeAttackTile2().add(AllTile[x+1][y]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
									this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
									}
								}	
								else if(y==4) {
									this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
									this.getJudgeAttackTile().add(AllTile[x+1][y]);								
									if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
										this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);
									}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y])) {
									this.getJudgeAttackTile2().add(AllTile[x+1][y]);
									}
								}
								else {
								this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
								this.getJudgeAttackTile().add(AllTile[x+1][y]);
								this.getJudgeAttackTile().add(AllTile[x+1][y+1]);
								if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
									this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);
								}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y]);
								}if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
								}
								}
									for(Tile d : judgeAttackTile) {
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
												this.getJudgeAttackTile2().remove(d);
												break;
											}											
										}																		
									}															
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							
							if((x-getLastUnitIChoose().getPosition().getTilex()==3&&y-getLastUnitIChoose().getPosition().getTiley()==0||
									(x-getLastUnitIChoose().getPosition().getTilex()==3&&y-getLastUnitIChoose().getPosition().getTiley()==-1)||
									(x-getLastUnitIChoose().getPosition().getTilex()==3&&y-getLastUnitIChoose().getPosition().getTiley()==1))
									) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[getLastUnitIChoose().getPosition().getTilex()+2][getLastUnitIChoose().getPosition().getTiley()]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[getLastUnitIChoose().getPosition().getTilex()+2][getLastUnitIChoose().getPosition().getTiley()])) {
							this.getJudgeAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()+2][getLastUnitIChoose().getPosition().getTiley()]);	
							}
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==getLastUnitIChoose().getPosition().getTilex()+2&&e.getPosition().getTiley()==getLastUnitIChoose().getPosition().getTiley()) 
										{
											this.getJudgeAttackTile2().remove(AllTile[getLastUnitIChoose().getPosition().getTilex()+2][getLastUnitIChoose().getPosition().getTiley()]);
											break;
										}											
									}																		
																							
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if((x-getLastUnitIChoose().getPosition().getTilex()==-3&&y-getLastUnitIChoose().getPosition().getTiley()==0)||
							(x-getLastUnitIChoose().getPosition().getTilex()==-3&&y-getLastUnitIChoose().getPosition().getTiley()==-1)||
							(x-getLastUnitIChoose().getPosition().getTilex()==-3&&y-getLastUnitIChoose().getPosition().getTiley()==1)
							) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[getLastUnitIChoose().getPosition().getTilex()-2][getLastUnitIChoose().getPosition().getTiley()]);	
							if(!this.getJudgeAttackTile2().contains(AllTile[getLastUnitIChoose().getPosition().getTilex()-2][getLastUnitIChoose().getPosition().getTiley()])) {
							this.getJudgeAttackTile2().add(AllTile[getLastUnitIChoose().getPosition().getTilex()-2][getLastUnitIChoose().getPosition().getTiley()]);	
							}
									for(Unit e : allUnit) {
										if(e.getPosition().getTilex()==getLastUnitIChoose().getPosition().getTilex()-2&&e.getPosition().getTiley()==getLastUnitIChoose().getPosition().getTiley()) {
											this.getJudgeAttackTile2().remove(AllTile[getLastUnitIChoose().getPosition().getTilex()-2][getLastUnitIChoose().getPosition().getTiley()]);
											break;
										}											
									}																		
																							
							if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
								this.getAttackTile().add(AllTile[catchX][catchY]);
							}
							this.getJudgeAttackTile().clear();
							this.getJudgeAttackTile2().clear();
							}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==2&&y-getLastUnitIChoose().getPosition().getTiley()==-2) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x-1][y+1]);
								if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y+1])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y+1]);	
								}
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==x-1&&e.getPosition().getTiley()==y+1) {
												this.getJudgeAttackTile2().remove(AllTile[x-1][y+1]);
												break;
											}											
										}																		
																								
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==2&&y-getLastUnitIChoose().getPosition().getTiley()==2) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x-1][y-1]);	
								if(!this.getJudgeAttackTile2().contains(AllTile[x-1][y-1])) {
								this.getJudgeAttackTile2().add(AllTile[x-1][y-1]);	
								}
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==x-1&&e.getPosition().getTiley()==y-1) {
												this.getJudgeAttackTile2().remove(AllTile[x-1][y-1]);
												break;
											}											
										}																		
																								
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==-2&&y-getLastUnitIChoose().getPosition().getTiley()==2) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x+1][y-1]);
								if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y-1])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y-1]);
								}
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==x+1&&e.getPosition().getTiley()==y-1) {
												this.getJudgeAttackTile2().remove(AllTile[x+1][y-1]);
												break;
											}											
										}																		
																								
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							if(x-getLastUnitIChoose().getPosition().getTilex()==-2&&y-getLastUnitIChoose().getPosition().getTiley()==-2) {
								this.getJudgeAttackTile2().clear();
								this.getJudgeAttackTile().add(AllTile[x+1][y+1]);	
								if(!this.getJudgeAttackTile2().contains(AllTile[x+1][y+1])) {
								this.getJudgeAttackTile2().add(AllTile[x+1][y+1]);
								}
										for(Unit e : allUnit) {
											if(e.getPosition().getTilex()==x+1&&e.getPosition().getTiley()==y+1) {
												this.getJudgeAttackTile2().remove(AllTile[x+1][y+1]);
												break;
											}											
										}																		
																								
								if(this.getJudgeAttackTile2().size()>0&&!this.getAttackTile().contains(AllTile[catchX][catchY])) {
									this.getAttackTile().add(AllTile[catchX][catchY]);
								}
								this.getJudgeAttackTile().clear();
								this.getJudgeAttackTile2().clear();
								}
							
							for(Tile d : directAttackTile) {
								for(Unit e : AiUnit) {
									if(e.getPosition().getTilex()==d.getTilex()&&e.getPosition().getTiley()==d.getTiley()) {
										this.getAttackTile().add(d);
										
									}											
								}																		
							}															
							//highlight
							if(attackTile.size()>0) {
							for(Tile f : attackTile) {
								BasicCommands.drawTile(out, f, 2);
								try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
							}
							}
						}

						}	

					}
			 }
		 
			 
		 
		 public ArrayList<Tile>getAttackTile(){
	    	 return attackTile;
	     }
		 
	     public ArrayList<Tile>getAttackCatchTile(){
	    	 return attackCatchTile;
	     }
	     public void setAttackCatchTile(ArrayList<Tile>tile){
	    	  this.attackCatchTile = tile;
	     }
	
	     public  ArrayList<Tile>getAllAttackTile(){
	    	 return allAttackTile;
	     }
	
	 	//clear attack highlight  shouda
	 	public void clearAttackRange(ActorRef out) {
	 		for(Tile hightTile : this.getAttackTile()) {
	 			BasicCommands.drawTile(out,hightTile, 0);
	 			try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
	 		}
	 		this.getAllAttackTile().clear();
	 		this.getAttackCatchTile().clear();	 		
	 		this.getAttackTile().clear();
	 		this.getDirectAttackTile().clear();
	 		this.getJudgeAttackTile().clear();
	 		this.getUinAttackTile().clear();
	 		this.getJudgeAttackTile2().clear();
	 	}
	 	
	 	public void setWhichTileIwantToAttack(Tile whichTileIwantToAttack) {
			this.whichTileIwantToAttack = whichTileIwantToAttack;
		}
		public Tile getWhichTileIwantToAttack() {
			return whichTileIwantToAttack;
		}
	 	
		public ArrayList<Tile> getDirectAttackTile() {
			return directAttackTile;
		}
		
		public ArrayList<Tile> getJudgeAttackTile() {
			return judgeAttackTile;
		}
		
		public ArrayList<Tile> getUinAttackTile() {
			return uinAttackTile;
		}
		
		public ArrayList<Tile> getJudgeAttackTile2() {
			return judgeAttackTile2;
		}
		
		public ArrayList<Tile> getMoveAndAttackTile() {
			return moveAndAttackTile;
		}
		public ArrayList<Tile> getMoveAndAttackTile2() {
			return moveAndAttackTile2;
		}
		public int getNumber1() {
			return number1;
		}
		
	    public ArrayList<Tile> getShowAllEmptyTile() {
			return showAllEmptyTile;
		}




		public void setShowAllEmptyTile(ArrayList<Tile> showAllEmptyTile) {
			this.showAllEmptyTile = showAllEmptyTile;
		}




		public ArrayList<Tile> getShowAllEmptytile2() {
			return showAllEmptytile2;
		}



		public void setShowAllEmptytile2(ArrayList<Tile> showAllEmptytile2) {
			this.showAllEmptytile2 = showAllEmptytile2;
		}



		public ArrayList<Tile> getFlytile() {
			return Flytile;
		}



		public void setFlytile(ArrayList<Tile> flytile) {
			Flytile = flytile;
		}


  //  show All empty Tile to summon  shouda
		public void showAllemptyTile(ActorRef out) {
			for (int i = 0; i < 9; i++) {
				for (int m = 0; m < 5; m++) {
					showAllEmptyTile.add(AllTile[i][m]);
				}
			}
			for (Unit unit : this.getAllUnit()) {
				int x = unit.getPosition().getTilex();
				int y = unit.getPosition().getTiley();
				if (this.showAllEmptyTile.contains(AllTile[x][y])) {
					this.showAllEmptyTile.remove(AllTile[x][y]);
				}

			}
			for (Tile tile : showAllEmptyTile) {
				BasicCommands.drawTile(out, tile, 1);
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}

		}
		// Ai unit planarScount active skills show deploy range
		public void planarScount() {
			
			for (int i = 0; i < 9; i++) {
				for (int m = 0; m < 5; m++) {
					showAllEmptyTile.add(AllTile[i][m]);
				}
			}
			for (Unit unit : this.getAllUnit()) {
				int x = unit.getPosition().getTilex();
				int y = unit.getPosition().getTiley();
				if (this.showAllEmptyTile.contains(AllTile[x][y])) {
					this.showAllEmptyTile.remove(AllTile[x][y]);
				}

			}
			
		}
		
		public void clearplanarScount() {
			showAllEmptyTile.clear();
		}
		
		
		public ArrayList<Tile> flyTileToMove () {
			for (int i = 0; i < 9; i++) {
				for (int m = 0; m < 5; m++) {
					this.Flytile.add(AllTile[i][m]);
				}
			}
			for (Unit unit : this.getAllUnit()) {
				int x = unit.getPosition().getTilex();
				int y = unit.getPosition().getTiley();
				if (this.Flytile.contains(AllTile[x][y])) {
					this.Flytile.remove(AllTile[x][y]);
				}

			}
			return Flytile;
		}
		
		public void  clearFlyTile() {
			this.Flytile.clear();
		}
		// shouda 7.4
		//random select a tile to move, Windshrike's effect 
		public void flyToTile(Unit unit,ArrayList<Tile> tile,ActorRef out) {
			Random rand = new Random(); 
			int randomNum=rand.nextInt(tile.size());
			Tile WhichTileIwantToMove = tile.get(randomNum);		
			BasicCommands.moveUnitToTile(out, unit, WhichTileIwantToMove);
			BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.move);
			try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
		}	
		
		
			public void attackthenflyToTile (Unit unit,ActorRef out,ArrayList<Unit> humanUnit) {
			Random rand = new Random();
			int randomNum=rand.nextInt(humanUnit.size());
			Unit whichUnitAiAttack =  humanUnit.get(randomNum);
			
			int x = whichUnitAiAttack.getPosition().getTilex();
			int y = whichUnitAiAttack.getPosition().getTiley();
			ArrayList<Tile> moveTileRange = new ArrayList<Tile>();
		
			if(x+1<9&&y<5&&x+1>=0&&y>=0) {
				
				moveTileRange.add(AllTile[x+1][y]);
				
			}
			if(x-1<9&&y<5&&x-1>=0&&y>=0) {
				
				moveTileRange.add(AllTile[x-1][y]);
				
			}
			if(x<9&&y+1<5&&x>=0&&y+1>=0) {
				
				moveTileRange.add(AllTile[x][y+1]);
				
			}
			if(x<9&&y-1<5&&x>=0&&y-1>=0) {
				moveTileRange.add(AllTile[x][y-1]);
				
			}
			if(x+1<9&&y+1<5&&x+1>=0&&y+1>=0) {
				
				moveTileRange.add( AllTile[x+1][y+1]);
			
			}
			if(x+1<9&&y-1<5&&x+1>=0&&y-1>=0) {
				
				moveTileRange.add(AllTile[x+1][y-1]);
				
			}
			if(x-1<9&&y+1<5&&x-1>=0&&y+1>=0) {
				
				moveTileRange.add(AllTile[x-1][y+1]);
				
			}
			if(x-1<9&&y-1<5&&x-1>=0&&y-1>=0) {
				
				moveTileRange.add(AllTile[x-1][y-1]);
			
			}
			//If the tile want to move has an unit
			for(Unit allunit: this.getAllUnit()) {
				int unitx = allunit.getPosition().getTilex();
				int unity = allunit.getPosition().getTiley();
				if(moveTileRange.contains(AllTile[unitx][unity])) {
					moveTileRange.remove(AllTile[unitx][unity]);
				}
				
			}
			//move first
			int randomTile=rand.nextInt(moveTileRange.size());
			Tile moveTile = moveTileRange.get(randomTile);
			BasicCommands.moveUnitToTile(out, unit, moveTile);
			BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.move);
			try {Thread.sleep(7000);} catch (InterruptedException e) {e.printStackTrace();}
			unit.setPositionByTile(moveTile);
			
			//attack and counterattack
			//Ai attack first
			BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.attack);
			try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
			int remainHealthhuman = whichUnitAiAttack.getHealth() - unit.getAttack();
			whichUnitAiAttack.setHealth(remainHealthhuman);
			BasicCommands.setUnitHealth(out, whichUnitAiAttack,  remainHealthhuman);
			if(whichUnitAiAttack.getHealth() <=0) {
				//human unit death
				BasicCommands.playUnitAnimation(out, whichUnitAiAttack, UnitAnimationType.death);
				try {Thread.sleep(2500);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.deleteUnit(out, whichUnitAiAttack);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				humanUnit.remove(whichUnitAiAttack);
				allUnit.remove(whichUnitAiAttack);
			}else{
				//human unit fight back
				BasicCommands.playUnitAnimation(out, whichUnitAiAttack, UnitAnimationType.attack);
				try {Thread.sleep(2500);} catch (InterruptedException e) {e.printStackTrace();}
				
				int remainHealthai = unit.getHealth() - whichUnitAiAttack.getAttack();
				unit.setHealth(remainHealthai);
				BasicCommands.setUnitHealth(out, unit, remainHealthai); 
				
			if(unit.getHealth()<=0) {
				// ai death
				BasicCommands.playUnitAnimation(out, unit, UnitAnimationType.death);
				try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.deleteUnit(out, unit);
				try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
				
				//7.11
				WindshrikeDie(unit,out,this);
				this.AiUnit.remove(unit);
				allUnit.remove(unit);
			
				//Ai unit:  if this unit die, the owner draw a card
				
			}
			
			
			}	
		}
			
	
			//Ai unit if this unit die, the owner draw a card  
			public void WindshrikeDie (Unit  Windshrike, ActorRef out,GameState gameState) {
				if( Windshrike.getId()==28) {
					if(gameState.getNumber2()<10) {
						if(this.getAiHandCard().size()<6) {
							this.drawAiOneCard(aiCard);
						}else {
							this.surplusAIHandCard(gameState);	
						}
						}else {
							BasicCommands.addPlayer1Notification(out, "Win",100);
						}
				}
					
					
			}	
		
	
		public void clearAllemptyTileHight(ActorRef out) {
			for (Tile tile : showAllEmptyTile) {
				BasicCommands.drawTile(out, tile, 0);
				try {
					Thread.sleep(30);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}showAllEmptyTile.clear();
		}



		public int getNumber2() {
			return number2;
		}



		public void setNumber2(int number2) {
			this.number2 = number2;
		}
			
		// attack+1 health+1 when enemy launch a spell card // 6.27 passive effect pureblade Enforcer
		public void improveAttHel(ActorRef out, GameState gameState) {

			for (Unit unit : gameState.getHumanUnit()) {
				if (unit.getId() == 6) {
					EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_buff);
					BasicCommands.playEffectAnimation(out, ef,
							gameState.getAllTile()[unit.getPosition().getTilex()][unit.getPosition().getTiley()]);
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, unit, unit.getAttack() + 1);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					unit.setAttack(unit.getAttack() + 1);
					if (unit.getHealth() < 4) {
						BasicCommands.playEffectAnimation(out, ef,
								gameState.getAllTile()[unit.getPosition().getTilex()][unit.getPosition().getTiley()]);
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						BasicCommands.setUnitHealth(out, unit, unit.getHealth() + 1);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						unit.setHealth(unit.getHealth() + 1);
					} else {
						BasicCommands.playEffectAnimation(out, ef,
								gameState.getAllTile()[unit.getPosition().getTilex()][unit.getPosition().getTiley()]);
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						BasicCommands.setUnitHealth(out, unit, 4);
						try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
						unit.setHealth(4);
					}

				}

			}

		}
		
		
		//when this unit is summoned,both players draw a card
		public void BlazeHoundDrawCard (ActorRef out,GameState gameState) {

             boolean win = false;
             boolean lost = false;
         if(lost!=true) {
         
			if(gameState.getNumber2()<10) { 
			if(gameState.getAiHandCard().size()<6) {
				gameState.drawAiOneCard(aiCard);
			}else {
				gameState.surplusAIHandCard(gameState);	
				
			}
			}else {
				BasicCommands.addPlayer1Notification(out, "Win",100);
				win=true;
			}
         }  
			
		if(win!=true) {	
			if(gameState.getNumber1()<10) {
			if(gameState.getHumanHandCard().size()<6) {
				BasicCommands.drawCard(out, gameState.drawHumanOneCard(gameState.getHumanCard()),
						gameState.getHumanHandCardNum(), 0);	
				try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
				
			}else {
				gameState.surplusHandCard(gameState);
			}
			}else {
				BasicCommands.addPlayer1Notification(out, "Lost",100);
				 lost=true;
			}
			
		}
			}
			
		
		
		
		//zhiwen 7.03
		public void summonAIAaimation (ActorRef out, GameState gameState, Tile t) {
			EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_summon);
			BasicCommands.playEffectAnimation(out, ef, t);
			try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
		}
		
		

		//zhiwen 6.30
		 public void AISummon(ActorRef out, GameState gameState) {
			 for(Card delet : usedCard) {
        		 AiHandCard.remove(delet);
        	 }
        	 for(Card c : AiHandCard) {//go through ai hand card，check if mana is sufficient，if true then deploy unit
        		 if(c.getCardname().equals("Staff of Y'Kir'")) {
        			 if(avatar2.getHealth()==20) {
        				 continue;
        			 }
        		 }
					if(getAiPlayer().getMana()>=c.getManacost()) {
						aiLoadUnitAndDeleteHandCard(c,out,gameState);
						int remainMana = getAiPlayer().getMana()-c.getManacost();
						getAiPlayer().setMana(remainMana);
						BasicCommands.setPlayer2Mana(out, aiPlayer);
					}
				}
		}
		 
		 
			//show deployment range  
			public void addSummonRange(ActorRef out,ArrayList<Unit> Unit) {
				for(Unit unitOnBoard :Unit) {
					//get the position of the unit
					int x=unitOnBoard.getPosition().getTilex();
					int y=unitOnBoard.getPosition().getTiley();
					
					if(x+1<9&&y<5&&x+1>=0&&y>=0) {
						
						this.getSummonTile().add(AllTile[x+1][y]);
						
					}
					if(x-1<9&&y<5&&x-1>=0&&y>=0) {
						
						this.getSummonTile().add(AllTile[x-1][y]);
						
					}
					if(x<9&&y+1<5&&x>=0&&y+1>=0) {
						
						this.getSummonTile().add(AllTile[x][y+1]);
						
					}
					if(x<9&&y-1<5&&x>=0&&y-1>=0) {
						
						this.getSummonTile().add(AllTile[x][y-1]);
						
					}
					if(x+1<9&&y+1<5&&x+1>=0&&y+1>=0) {
						
						this.getSummonTile().add( AllTile[x+1][y+1]);
					
					}
					if(x+1<9&&y-1<5&&x+1>=0&&y-1>=0) {
						
						this.getSummonTile().add(AllTile[x+1][y-1]);
						
					}
					if(x-1<9&&y+1<5&&x-1>=0&&y+1>=0) {
						
						this.getSummonTile().add(AllTile[x-1][y+1]);
						
					}
					if(x-1<9&&y-1<5&&x-1>=0&&y-1>=0) {
						
						this.getSummonTile().add(AllTile[x-1][y-1]);
					
					}
					
				}  
		    }
			
			
            public void aiLoadUnitAndDeleteHandCard(Card c, ActorRef out, GameState gameState) {
           	 if(c.getCardname().equals("Planar Scout")){
           		 planarScount();//Random Full Map Deployment
                	Random rand = new Random(); 
        			int randomNum=rand.nextInt(showAllEmptyTile.size());
        			Tile WhichTileIwantToSummon = showAllEmptyTile.get(randomNum);	

 					Unit u_planar_scout = 
 							BasicObjectBuilders.loadUnit(StaticConfFiles.u_planar_scout, 23, Unit.class);
 					this.summonAIAaimation(out, this,WhichTileIwantToSummon);
 					try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
 					u_planar_scout.setPositionByTile(WhichTileIwantToSummon); 
 					BasicCommands.drawUnit(out, u_planar_scout, WhichTileIwantToSummon);
 					u_planar_scout.setAttack(2);
 					u_planar_scout.setHealth(1);
 					u_planar_scout.setMaxHealth(1);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					BasicCommands.setUnitAttack(out, u_planar_scout, 2);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					BasicCommands.setUnitHealth(out, u_planar_scout, 1);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					this.getAiUnit().add(u_planar_scout);
 					this.getAllUnit().add(u_planar_scout);
 					usedCard.add(planar_scout);
 					clearplanarScount();
 				}
           	 
           	 addSummonRange(out, AiUnit);
           	 Tile randomTile = this.randomSelectRange();
           	 if(c.getCardname().equals("Hailstone GolemR")){
// 					showSummonRange(out, AiUnit);
 					Unit u_hailstone_golem = 
 							BasicObjectBuilders.loadUnit(StaticConfFiles.u_hailstone_golemR, 21, Unit.class);
 					this.summonAIAaimation(out, this,randomTile);
 					u_hailstone_golem.setPositionByTile(randomTile); 
 					BasicCommands.drawUnit(out, u_hailstone_golem, randomTile);
 					u_hailstone_golem.setAttack(4);
 					u_hailstone_golem.setHealth(6);
 					u_hailstone_golem.setMaxHealth(6);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					BasicCommands.setUnitAttack(out, u_hailstone_golem, 4);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					BasicCommands.setUnitHealth(out, u_hailstone_golem, 6);
 					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
 					this.AiUnit.add(u_hailstone_golem);
 					this.allUnit.add(u_hailstone_golem);
// 	
 					usedCard.add(hailstone_golemR);
 				}
				if(c.getCardname().equals("Blaze Hound")){
					
//					showSummonRange(out, AiUnit);
					Unit u_blaze_hound = 
							 BasicObjectBuilders.loadUnit(StaticConfFiles.u_blaze_hound, 22, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_blaze_hound.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_blaze_hound, randomTile);
					u_blaze_hound.setAttack(4);
					u_blaze_hound.setHealth(3);
					u_blaze_hound.setMaxHealth(3);
					u_blaze_hound.setDrawCardState(1);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_blaze_hound, 4);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_blaze_hound, 3);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_blaze_hound);
					this.getAllUnit().add(u_blaze_hound);
					usedCard.add(blaze_hound);
					
					// 7.4  Each side draws a card for passive effect ;shouda
			       //  
				}
				
				if(c.getCardname().equals("Bloodshard Golem")){
//					showSummonRange(out, AiUnit);
					Unit u_bloodshard_golem = 
							BasicObjectBuilders.loadUnit(StaticConfFiles.u_bloodshard_golem, 24, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_bloodshard_golem.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_bloodshard_golem, randomTile);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_bloodshard_golem, 4);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_bloodshard_golem, 3);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_bloodshard_golem);
					u_bloodshard_golem.setAttack(4);
					u_bloodshard_golem.setHealth(3);
					u_bloodshard_golem.setMaxHealth(3);
					this.getAllUnit().add(u_bloodshard_golem);
//					AiHandCard.remove(bloodshard_golem);
					usedCard.add(bloodshard_golem);
					}
				if(c.getCardname().equals("Pyromancer")){
//					showSummonRange(out, AiUnit);
					Unit u_pyromancer = 
							BasicObjectBuilders.loadUnit(StaticConfFiles.u_pyromancer, 25, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_pyromancer.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_pyromancer, randomTile);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_pyromancer, 2);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_pyromancer, 1);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_pyromancer);
					u_pyromancer.setAttack(2);
					u_pyromancer.setHealth(1);
					u_pyromancer.setMaxHealth(1);
					this.getAllUnit().add(u_pyromancer);
//					AiHandCard.remove(pyromancer);
					usedCard.add(pyromancer);
					}
				if(c.getCardname().equals("Rock Pulveriser")){
//					showSummonRange(out, AiUnit);
					Unit u_rock_pulveriser = 
							BasicObjectBuilders.loadUnit(StaticConfFiles.u_rock_pulveriser, 26, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_rock_pulveriser.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_rock_pulveriser, randomTile);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_rock_pulveriser, 1);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_rock_pulveriser, 4);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_rock_pulveriser);
					u_rock_pulveriser.setAttack(1);
					u_rock_pulveriser.setHealth(4);
					u_rock_pulveriser.setMaxHealth(4);
					this.getAllUnit().add(u_rock_pulveriser);
//					AiHandCard.remove(rock_pulveriser);
					usedCard.add(rock_pulveriser);
					}
				if(c.getCardname().equals("Serpenti")){
//					showSummonRange(out, AiUnit);
					Unit u_serpenti = 
							BasicObjectBuilders.loadUnit(StaticConfFiles.u_serpenti, 27, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_serpenti.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_serpenti, randomTile);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_serpenti, 7);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_serpenti, 4);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_serpenti);
					u_serpenti.setAttack(7);
					u_serpenti.setHealth(4);
					u_serpenti.setMaxHealth(4);
					this.getAllUnit().add(u_serpenti);
//					AiHandCard.remove(serpenti);
					usedCard.add(serpenti);
					}
				if(c.getCardname().equals("WindShrike")){
//					showSummonRange(out, AiUnit);
					Unit u_windShrike = 
							BasicObjectBuilders.loadUnit(StaticConfFiles.u_windshrike, 28, Unit.class);
					this.summonAIAaimation(out, this,randomTile);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					u_windShrike.setPositionByTile(randomTile); 
					BasicCommands.drawUnit(out, u_windShrike, randomTile);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitAttack(out, u_windShrike, 4);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.setUnitHealth(out, u_windShrike, 3);
					try {Thread.sleep(100);} catch (InterruptedException e) {e.printStackTrace();}
					this.getAiUnit().add(u_windShrike);
					u_windShrike.setAttack(4);
					u_windShrike.setHealth(3);
					u_windShrike.setMaxHealth(3);
					this.getAllUnit().add(u_windShrike);
//					AiHandCard.remove(windshrike);
					usedCard.add(windshrike);
					}
				if(c.getCardname().equals("Staff of Y'Kir'")){
					usedCard.add(staff_of_ykir);
					EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_buff);
					BasicCommands.playEffectAnimation(out, ef, AllTile[getAvatar2().getPosition().getTilex()][getAvatar2().getPosition().getTiley()]);
					try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
					if(getAvatar2().getHealth()<=18) {
						getAvatar2().setHealth(getAvatar2().getHealth()+2);
						getAiPlayer().setHealth(getAiPlayer().getHealth()+2);
						BasicCommands.setUnitHealth(out, getAvatar2(), getAvatar2().getHealth());
						BasicCommands.setPlayer2Health(out, aiPlayer);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}else {
						getAvatar2().setHealth(20);
						BasicCommands.setUnitHealth(out, getAvatar2(), 20);
						getAiPlayer().setHealth(20);
						BasicCommands.setPlayer2Health(out, aiPlayer);
						try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
				
					improveAttHel(out, gameState);
					}
				if(c.getCardname().equals("Entropic Decay")){
					usedCard.add(entropic_decay);

					Random rand = new Random();
 					while(true) {
 						int randomNum=rand.nextInt(getHumanUnit().size());
 						Unit  humanUnit = this.getHumanUnit().get(randomNum);
 						if( humanUnit.getId()!=1) {
 							 humanUnit.setHealth(0);
 							EffectAnimation f = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_martyrdom);
 							
 							BasicCommands.playEffectAnimation(out, f, AllTile[ humanUnit
 							                .getPosition().getTilex()][ humanUnit.getPosition().getTiley()]);
 							try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
 							
 							BasicCommands.playUnitAnimation(out, getHumanUnit().get(randomNum), UnitAnimationType.death);
 							try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
 							BasicCommands.deleteUnit(out, getHumanUnit().get(randomNum));
 							this.allUnit.remove(humanUnit);
 							this.humanUnit.remove(humanUnit);
 							
 							break;
 						}
 					}

					improveAttHel(out, gameState);
					}
				clearSummonRange(out);
				clearHightRed(out);
			}
            
            public Tile randomSelectRange() {
           	int ranNum = ranNum();
				boolean unitOnTile = false;
				for(Unit u : this.getAllUnit()) {
					if(u.getPosition().getTilex() == this.getSummonTile().get(ranNum).getTilex()
							&& u.getPosition().getTiley() == this.getSummonTile().get(ranNum).getTiley()) {
						unitOnTile = true;
					}
				}
				if(unitOnTile == false) {
					return this.getSummonTile().get(ranNum);
				}else {
					return randomSelectRange();
				}
			}
			
			public int ranNum() {
				int ranNum = (int)(Math.random()*this.getSummonTile().size());
				return ranNum;
			}
				
			
	//  7.10 ning。 xiaoyuan
			
		
		    public ArrayList<Tile> getAiMoveTile() {
				return aiMoveTile;
			}
			public ArrayList<Tile> getAiMoveTile2() {
				return aiMoveTile2;
			}
			public ArrayList<Tile> getAiAttackCatchTile() {
				return aiAttackCatchTile;
			}		
			public ArrayList<Tile> getAiFinalMoveTile() {
				return aiFinalMoveTile;
			}			
			public ArrayList<Tile> getAiCanAttackTile(){
				return aiCanAttackTile;
			}		

			public ArrayList<Unit> getAiUnit2(){
				return aiUnit2;
			}	
			public ArrayList<Unit> getHumanUnit2(){
				return humanUnit2;
			}
			
			
			public ArrayList<Tile> getEveryTile(){	
				everyTile.clear();
				for(int i=0;i<9;i++) {
					for(int m=0;m<5;m++) {
						everyTile.add(AllTile[i][m]);
					}
				}
				return everyTile;
			}

			public Tile getRock() {
				Tile rock = null;
				for(Unit a:AiUnit) {
					if (a.getId()==26) {
						rock = AllTile[a.getPosition().getTilex()][a.getPosition().getTiley()];
						break;
					}
				}
				return rock;
			}
			
			public int getSilverX() {
				int silverx = 100;
				for(Unit a:humanUnit) {
					if (a.getId()==8) {
						silverx = a.getPosition().getTilex();
						break;
					}
				}
				return silverx;
			}
			public int getSilverY() {
				int silvery = 100;
				for(Unit a:humanUnit) {
					if (a.getId()==8) {
						silvery = a.getPosition().getTiley();
						break;
					}
				}
				return silvery;
			}
			
			public Unit getSilver() {
				Unit silver = null;
				for(Unit a:humanUnit) {
					if (a.getId()==8) {
						silver = a;
						break;
					}
				}
				return silver;
			}
		
			public Unit getSerpenti() {
				Unit serpenti = null;
				for(Unit a:AiUnit) {
					if (a.getId()==27) {
						serpenti = a;
						break;
					}
				}
				return serpenti;
			}
			
			public Unit getPyromancer() {
				Unit pyromancer = null;
				for(Unit a:AiUnit) {
					if (a.getId()==25) {
						pyromancer = a;
						break;
					}
				}
				return pyromancer;
			}
			
			public int getIronX() {
				int ironx = 100;
				for(Unit a:humanUnit) {
					if (a.getId()==9) {
						ironx = a.getPosition().getTilex();
						break;
					}
				}
				return ironx;
			}
			
			public int getIronY() {
				int irony = 100;
				for(Unit a:humanUnit) {
					if (a.getId()==9) {
						irony = a.getPosition().getTiley();
						break;
					}
				}
				return irony;
			}
			
			public Unit getIron() {
				Unit iron = null;
				for(Unit a:humanUnit) {
					if (a.getId()==9) {
						iron = a;
						break;
					}
				}
				return iron;
			}
	
			// shows win or lose 
			   public void avatarDead (Unit unit,ActorRef out ) {
			    if(unit.getId()==1&&unit.getHealth()<=0) {
			     BasicCommands.addPlayer1Notification(out, "Lost",100);
			     this.setGameEnd(1);
			    }else if(unit.getId()==20&&unit.getHealth()<=0) {
			     BasicCommands.addPlayer1Notification(out, "Win",100);
			     this.setGameEnd(1);
			    }
			   }



			public int getGameEnd() {
				return gameEnd;
			}



			public void setGameEnd(int gameEnd) {
				this.gameEnd = gameEnd;
			}			
	
	
	      
	
	
	
	
	  
}
