
/* @author 
 * 2521509R
 * 2537942N
 * 2531726C
 * 2530845L
 * 2558276L
 */

package events;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import structures.GameState;


/**
 * Indicates that both the core game loop in the browser is starting, meaning
 * that it is ready to recieve commands from the back-end.
 * 
 * { 
 *   messageType = “initalize”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class Initalize implements EventProcessor{


	@Override                  
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		gameState.initilize(out);
		
	}

}


