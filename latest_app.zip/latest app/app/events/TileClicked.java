
/* @author 
 * 2521509R
 * 2537942N
 * 2531726C
 * 2530845L
 * 2558276L
 */

package events;



import java.util.ArrayList;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.Card;
import structures.basic.EffectAnimation;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitAnimationType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;

/**
 * Indicates that the user has clicked an object on the game canvas, in this case a tile.
 * The event returns the x (horizontal) and y (vertical) indices of the tile that was
 * clicked. Tile indices start at 1.
 * 
 * { 
 *   messageType = “tileClicked”
 *   tilex = <x index of the tile>
 *   tiley = <y index of the tile>
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class TileClicked implements EventProcessor{



	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {

		int tilex = message.get("tilex").asInt();
		int tiley = message.get("tiley").asInt();

		Unit theUnitIChoose = gameState.getLastUnitIChoose();
		Card myChooseCard = gameState.getWhichCardIchhose();
		int aiCardNumber = gameState.getNumber2();
		int HumanCardNumber = gameState.getNumber1();
		int humanMana = gameState.getHumanPlayer().getMana();
		int HumanHealth = gameState.getHumanPlayer().getHealth();
//		  
		if (HumanCardNumber < 11 && aiCardNumber < 11 && gameState.getAiUnit().contains(gameState.getAvatar2()) && HumanHealth > 0) {
			 //game stop
			if(HumanCardNumber==10) {
				  gameState.setNumber1(11);
			  }
			  if(aiCardNumber==10) {
				  gameState.setNumber2(11);
			  }
     
//			//handcard deploy
		if (myChooseCard != null) {
			int cardMana = gameState.getWhichCardIchhose().getManacost();
			int handcardPos = gameState.getWhichCardIchoosePosition();
			// 6.25  shouda and Xinyi
			gameState.setWhichTileIwantTosummon(gameState.getAllTile()[tilex][tiley]);
			boolean ifInTheSummonTile = false;
			boolean ifUnitOnTheTile = false;
			boolean ifTileIsRed = false;
			// 7.2 shouda and Xinyi
			boolean onallSumTile = false;

			for (Tile tile : gameState.getShowAllEmptyTile()) {
				if (tile.getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
						&& tile.getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
					gameState.setWhichCardIchhose(null);
					onallSumTile = true;
				}
			}
	
			for (Tile t : gameState.getSummonTile()) {//check if the clicked tile is the tile which can summon unit
				if (t.getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
						&& t.getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
					// 6.27 shou'da
					gameState.setWhichCardIchhose(null);
					ifInTheSummonTile = true;

				}
			}
			for (Unit u : gameState.getAllUnit()) {//check if there is any unit on the clicked tile
				if (u.getPosition().getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
						&& u.getPosition().getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
					ifUnitOnTheTile = true;
				}
			}
			if (onallSumTile == true && ifUnitOnTheTile == false) {//Ironcliff Guardian can be summoned on all tile, need to check if clecked tile has unit
				if (myChooseCard.getCardname().equals("Ironcliff Guardian")) {
					Unit Ironcliff_Guardian = BasicObjectBuilders.loadUnit(StaticConfFiles.u_ironcliff_guardian, 9,
							Unit.class);
					gameState.summonAaimation(out, gameState);
					Ironcliff_Guardian.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Ironcliff_Guardian, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Ironcliff_Guardian, 3);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Ironcliff_Guardian, 10);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(Ironcliff_Guardian);
					Ironcliff_Guardian.setAttack(3);
					Ironcliff_Guardian.setHealth(10);
					Ironcliff_Guardian.setMaxHealth(10);

					gameState.getAllUnit().add(Ironcliff_Guardian);
				}
				gameState.setWhichUnitIChoose(null);

				int remainMna = humanMana - cardMana;
				stateUpdate(out, gameState, remainMna, handcardPos, myChooseCard);

			}
			// deploy AUTHOR: Zhiwen and Xinyi 
			else if (ifInTheSummonTile == true && ifUnitOnTheTile == false) {// check if the clicked tile is the tile which unit can be summoned, and if the tile is empty
				if (myChooseCard.getCardname().equals("Comodo Charger")) {
					Unit comodo_charger = BasicObjectBuilders.loadUnit(StaticConfFiles.u_comodo_charger, 2, Unit.class);
					gameState.summonAaimation(out, gameState);
					comodo_charger.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, comodo_charger, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, comodo_charger, 1);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, comodo_charger, 3);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(comodo_charger);
					comodo_charger.setAttack(1);
					comodo_charger.setHealth(3);
					comodo_charger.setMaxHealth(3);
					gameState.getAllUnit().add(comodo_charger);
				}

				if (myChooseCard.getCardname().equals("Hailstone Golem")) {
					Unit HailstoneGolem = BasicObjectBuilders.loadUnit(StaticConfFiles.u_hailstone_golem, 3,
							Unit.class);
					gameState.summonAaimation(out, gameState);
					HailstoneGolem.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, HailstoneGolem, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, HailstoneGolem, 4);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, HailstoneGolem, 6);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(HailstoneGolem);
					HailstoneGolem.setAttack(4);
					HailstoneGolem.setHealth(6);
					HailstoneGolem.setMaxHealth(6);
					gameState.getAllUnit().add(HailstoneGolem);
				}
				if (myChooseCard.getCardname().equals("Azure Herald")) {
					Unit Azure_Herald = BasicObjectBuilders.loadUnit(StaticConfFiles.u_azure_herald, 4, Unit.class);
					gameState.summonAaimation(out, gameState);
					Azure_Herald.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Azure_Herald, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Azure_Herald, 1);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Azure_Herald, 4);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(Azure_Herald);
					Azure_Herald.setAttack(1);
					Azure_Herald.setHealth(4);
					// zhiwen
					Azure_Herald.setMaxHealth(4);
					giveAvatarThreeHealth(out, gameState);
					gameState.getAllUnit().add(Azure_Herald);
				}
				if (myChooseCard.getCardname().equals("Azurite Lion")) {
					Unit Azurite_Lion = BasicObjectBuilders.loadUnit(StaticConfFiles.u_azurite_lion, 5, Unit.class);
					gameState.summonAaimation(out, gameState);
					Azurite_Lion.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Azurite_Lion, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Azurite_Lion, 2);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Azurite_Lion, 3);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(Azurite_Lion);
					Azurite_Lion.setAttack(2);
					Azurite_Lion.setHealth(3);
					Azurite_Lion.setMaxHealth(3);
					gameState.getAllUnit().add(Azurite_Lion);
				}
				if (myChooseCard.getCardname().equals("Pureblade Enforcer")) {
					Unit Pureblade_Enforcer = BasicObjectBuilders.loadUnit(StaticConfFiles.u_pureblade_enforcer, 6,
							Unit.class);
					gameState.summonAaimation(out, gameState);
					Pureblade_Enforcer.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Pureblade_Enforcer, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Pureblade_Enforcer, 1);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Pureblade_Enforcer, 4);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getAllUnit().add(Pureblade_Enforcer);
					gameState.getHumanUnit().add(Pureblade_Enforcer);
					Pureblade_Enforcer.setAttack(1);
					Pureblade_Enforcer.setHealth(4);
					Pureblade_Enforcer.setMaxHealth(4);
					
				}
				if (myChooseCard.getCardname().equals("Fire Spitter")) {
					Unit Fire_Spitter = BasicObjectBuilders.loadUnit(StaticConfFiles.u_fire_spitter, 7, Unit.class);
					gameState.summonAaimation(out, gameState);
					Fire_Spitter.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Fire_Spitter, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Fire_Spitter, 3);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Fire_Spitter, 2);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(Fire_Spitter);
					Fire_Spitter.setAttack(3);
					Fire_Spitter.setHealth(2);
					Fire_Spitter.setMaxHealth(2);
					gameState.getAllUnit().add(Fire_Spitter);

				}
				if (myChooseCard.getCardname().equals("Silverguard Knight")) {
					Unit Silverguard_Knight = BasicObjectBuilders.loadUnit(StaticConfFiles.u_silverguard_knight, 8,
							Unit.class);
					gameState.summonAaimation(out, gameState);
					Silverguard_Knight.setPositionByTile(gameState.getWhichTileIwantTosummon());
					BasicCommands.drawUnit(out, Silverguard_Knight, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitAttack(out, Silverguard_Knight, 1);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					BasicCommands.setUnitHealth(out, Silverguard_Knight, 5);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					gameState.getHumanUnit().add(Silverguard_Knight);
					Silverguard_Knight.setAttack(1);
					Silverguard_Knight.setHealth(5);
					Silverguard_Knight.setMaxHealth(5);
					gameState.getAllUnit().add(Silverguard_Knight);

				}

				// 6.27 shouda . This method prevents post-deployment unit selection from being highlighted
				gameState.setWhichUnitIChoose(null);

				int remainMna = humanMana - cardMana;
				stateUpdate(out, gameState, remainMna, handcardPos, myChooseCard);
				
			}
			for (Tile t : gameState.getHightRed()) {
				if (t.getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
						&& t.getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
					ifTileIsRed = true;
				}
			}
			if (ifTileIsRed == true) {
				if (myChooseCard.getCardname().equals("Truestrike")) {
					EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_inmolation);
					BasicCommands.playEffectAnimation(out, ef, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					twoDamage(out, gameState);

				}
				if (myChooseCard.getCardname().equals("Sundrop Elixir")) {
					EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_buff);
					BasicCommands.playEffectAnimation(out, ef, gameState.getWhichTileIwantTosummon());
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					addHealth(out, gameState);

				}
				gameState.setSpellState(1);
				gameState.setWhichUnitIChoose(null);

				int remainMna = humanMana - cardMana;
				stateUpdate(out, gameState, remainMna, handcardPos, myChooseCard);
			}

			gameState.superClear(out, gameState);
		}

		// 9.28 Using a spell card automatically lights up range of movement
		if (gameState.getSpellState() == 1) {
			gameState.clearMoveRange(out);
			gameState.setSpellState(0);
		} else {

			gameState.moveTileHighlight(out, gameState, message);
			if (theUnitIChoose != null) {

				gameState.move(out, gameState, message);
				gameState.attack(out, gameState, message);
			}
		}

	}else {
		if(HumanCardNumber>10||HumanHealth <=0) {
			BasicCommands.addPlayer1Notification(out, "Lost",100);
		}else {
			BasicCommands.addPlayer1Notification(out, "Win",100);
		}
	}
	}

	public void stateUpdate(ActorRef out, GameState gameState, int remainMna, int handcardPos, Card myChooseCard) {
		gameState.getHumanPlayer().setMana(remainMna);
		BasicCommands.setPlayer1Mana(out, gameState.getHumanPlayer());
		BasicCommands.deleteCard(out, handcardPos);
		gameState.getHumanHandCard().remove(myChooseCard);
		gameState.setWhichCardIchhose(null);
		for (int i = 0; i < gameState.getHumanHandCard().size(); i++) {
			BasicCommands.drawCard(out, gameState.getHumanHandCard().get(i), i + 1, 0);
		}
		BasicCommands.deleteCard(out, gameState.getHumanHandCard().size() + 1);
		gameState.clearSummonRange(out);
		gameState.clearHightRed(out);
	}

	public void giveAvatarThreeHealth(ActorRef out, GameState gameState) {
		int avatar1Health = gameState.getAvatar1().getHealth();
		EffectAnimation ef = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_buff);
		BasicCommands.playEffectAnimation(out, ef,
				gameState.getAllTile()[gameState.getAvatar1().getPosition().getTilex()][gameState.getAvatar1()
						.getPosition().getTiley()]);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (avatar1Health + 3 <= 20) {
			gameState.getAvatar1().setHealth(avatar1Health + 3);
			gameState.getHumanPlayer().setHealth(avatar1Health + 3);
			BasicCommands.setPlayer1Health(out, gameState.getHumanPlayer());
			BasicCommands.setUnitHealth(out, gameState.getAvatar1(), avatar1Health + 3);
		} else {
			gameState.getAvatar1().setHealth(20);
			gameState.getHumanPlayer().setHealth(20);
			BasicCommands.setPlayer1Health(out, gameState.getHumanPlayer());
			BasicCommands.setUnitHealth(out, gameState.getAvatar1(), 20);
		}

	}

	public void twoDamage(ActorRef out, GameState gameState) {
		ArrayList<Unit>  usedUnit = new ArrayList<Unit>();
		for (Unit aiUnit : gameState.getAiUnit()) {
			if (aiUnit.getPosition().getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
					&& aiUnit.getPosition().getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
				int health = aiUnit.getHealth();
				aiUnit.setHealth(health - 2);
				BasicCommands.setUnitHealth(out, aiUnit, health - 2);
				if (health - 2 <= 0) {
					BasicCommands.playUnitAnimation(out, aiUnit, UnitAnimationType.death);
					try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.deleteUnit(out, aiUnit);

					usedUnit.add(aiUnit);
					 break;
				}
				if (aiUnit.getId() == 20) {
					gameState.getAiPlayer().setHealth(gameState.getAiPlayer().getHealth() - 2);
					BasicCommands.setPlayer2Health(out, gameState.getAiPlayer());
				} 
			} 
		} 
		for(Unit u : usedUnit) {
			gameState.getAiUnit().remove(u);
			gameState.getAllUnit().remove(u);
		} 
	}

	// Sundrop Elixir’s effect  ,AUTHOR: Zhiwen and Xinyi  
	public void addHealth(ActorRef out, GameState gameState) {
		for (Unit aiUnit : gameState.getAiUnit()) {
			if (aiUnit.getPosition().getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
					&& aiUnit.getPosition().getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
				int health = aiUnit.getHealth();
				if (health + 5 <= aiUnit.getMaxHealth()) {
					aiUnit.setHealth(health + 5);
					BasicCommands.setUnitHealth(out, aiUnit, health + 5);
				} else {
					aiUnit.setHealth(aiUnit.getMaxHealth());
					BasicCommands.setUnitHealth(out, aiUnit, aiUnit.getMaxHealth());
				}
				if (aiUnit.getId() == 20) {
					if (health + 5 <= aiUnit.getMaxHealth()) {
						gameState.getAiPlayer().setHealth(health + 5);
						BasicCommands.setPlayer2Health(out, gameState.getAiPlayer());
					} else {
						gameState.getAiPlayer().setHealth(aiUnit.getMaxHealth());
						BasicCommands.setPlayer2Health(out, gameState.getAiPlayer());
					}
				}
			} 
		}
			// The for down here is to increase the health of your unit
		for (Unit humanUnit : gameState.getHumanUnit()) {
			if (humanUnit.getPosition().getTilex() == gameState.getWhichTileIwantTosummon().getTilex()
					&& humanUnit.getPosition().getTiley() == gameState.getWhichTileIwantTosummon().getTiley()) {
				int health = humanUnit.getHealth();
				if (health + 5 <= humanUnit.getMaxHealth()) {
					humanUnit.setHealth(health + 5);
					BasicCommands.setUnitHealth(out, humanUnit, health + 5);
				} else {
					humanUnit.setHealth(humanUnit.getMaxHealth());
					BasicCommands.setUnitHealth(out, humanUnit, humanUnit.getMaxHealth());
				}
				if (humanUnit.getId() == 1) {
					if (health + 5 <= humanUnit.getMaxHealth()) {
						gameState.getHumanPlayer().setHealth(health + 5);
						BasicCommands.setPlayer1Health(out, gameState.getHumanPlayer());
					} else {
						gameState.getHumanPlayer().setHealth(humanUnit.getMaxHealth());
						BasicCommands.setPlayer1Health(out, gameState.getHumanPlayer());
					}
				}
			} 
		} 
	}



	///

}
