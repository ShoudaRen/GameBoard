
/* @author 
 * 2521509R
 * 2537942N
 * 2531726C
 * 2530845L
 * 2558276L
 */

package events;

import java.util.Random;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.EffectAnimation;
import structures.basic.Tile;
import structures.basic.Unit;
import structures.basic.UnitAnimationType;
import utils.BasicObjectBuilders;
import utils.StaticConfFiles;
/**
 * Indicates that the user has clicked an object on the game canvas, in this case
 * the end-turn button.
 * 
 * { 
 *   messageType = “endTurnClicked”
 * }
 * 
 * @author Dr. Richard McCreadie
 *
 */
public class EndTurnClicked implements EventProcessor{
  // private Initalize a;
	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {
		
		
		
	// clear all effect and clear state 
		gameState.clearMoveRange(out);
		gameState.clearAttackRange(out);
		gameState.clearAllemptyTileHight(out);
		gameState.clearSummonRange(out);
		gameState.clearHightRed(out);
	
		// win or lose and whether could be triggered // shouda 7.10
		if(gameState.getNumber1()<11&&gameState.getNumber2()<11
				&&gameState.getHumanPlayer().getHealth()>0&&gameState.getAiUnit().contains(gameState.getAvatar2())) {
			
			 //game stop
			if(gameState.getNumber1()==10) {
				  gameState.setNumber1(11);
			  }
			  if(gameState.getNumber2()==10) {
				  gameState.setNumber2(11);
			  }	
		
		// zhiwen 7.4 
		gameState.AISummon(out,gameState);
		
		//Blaze Hound draw card
		for(Unit allunit: gameState.getAllUnit()) {
			if(allunit.getId()==22&&allunit.getDrawCardState()==1) {
				gameState.BlazeHoundDrawCard(out, gameState);
				allunit.setDrawCardState(0);
				break;
			}
		}
	
		//Pyromancer
		if(gameState.getAiUnit().contains(gameState.getPyromancer())&&gameState.getPyromancer().getAttackChance()>0) {
			Unit targ;
			if( (gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==-1)||
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==0&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==-1)||	
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==-1)||
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==0)||	
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==0)||
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==1)||	
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==0&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==1)||
					(gameState.getSilverX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getSilverY()-gameState.getPyromancer().getPosition().getTiley()==1)) {
				targ=gameState.getSilver();			
			}
			else if( (gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==-1)||
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==0&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==-1)||	
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==-1)||
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==0)||	
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==0)||
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==-1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==1)||	
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==0&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==1)||
					(gameState.getIronX()-gameState.getPyromancer().getPosition().getTilex()==1&&gameState.getIronY()-gameState.getPyromancer().getPosition().getTiley()==1)) {
				targ=gameState.getIron();			
			}
			
			else {
				targ=gameState.getAvatar1();
			}
				
				EffectAnimation projectile = BasicObjectBuilders.loadEffect(StaticConfFiles.f1_projectiles);
				BasicCommands.playUnitAnimation(out, gameState.getPyromancer(), UnitAnimationType.attack);
				try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
				BasicCommands.playProjectileAnimation(out, projectile, 0, gameState.getAllTile()[gameState.getPyromancer().getPosition().getTilex()][gameState.getPyromancer().getPosition().getTiley()]
						, gameState.getAllTile()[targ.getPosition().getTilex()][targ.getPosition().getTiley()]);
			
				BasicCommands.playUnitAnimation(out, gameState.getPyromancer(), UnitAnimationType.idle);
				gameState.getPyromancer().deleteAttackChance();
				int remainHealthSilver0 = targ.getHealth() - gameState.getPyromancer().getAttack();
				targ.setHealth(remainHealthSilver0);
				BasicCommands.setUnitHealth(out, targ, remainHealthSilver0); 
																
				if(targ.getHealth() <=0) {
					BasicCommands.playUnitAnimation(out, targ, UnitAnimationType.death);
					try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.deleteUnit(out, targ);
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					if(targ!=gameState.getAvatar1()) {
						gameState.getHumanUnit().remove(targ);
						gameState.getAllUnit().remove(targ);
					}
				}
				//provoke 
				else if( (targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==-1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==-1)||
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==0&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==-1)||	
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==-1)||
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==-1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==0)||	
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==0)||
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==-1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==1)||	
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==0&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==1)||
						(targ.getPosition().getTilex()-gameState.getPyromancer().getPosition().getTilex()==1&&targ.getPosition().getTiley()-gameState.getPyromancer().getPosition().getTiley()==1)) {
				
				// update state 
					BasicCommands.playUnitAnimation(out, targ, UnitAnimationType.attack);
					try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}													
					int remainHealthPy = gameState.getPyromancer().getHealth() - targ.getAttack();
					gameState.getPyromancer().setHealth(remainHealthPy);
					BasicCommands.setUnitHealth(out, gameState.getPyromancer(), remainHealthPy); 
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}													
					if(gameState.getPyromancer().getHealth()<=0) {
					BasicCommands.playUnitAnimation(out, gameState.getPyromancer(), UnitAnimationType.death);
					try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
					BasicCommands.deleteUnit(out, gameState.getPyromancer());
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					gameState.getAllUnit().remove(gameState.getPyromancer());
					gameState.getAiUnit().remove(gameState.getPyromancer());
					
					}
				}
				gameState.avatarDead (gameState.getAvatar1(), out);
			
		}
	
		
		
		if(gameState.getAiUnit().contains(gameState.getAvatar2())) {            
		    
		// implementation for Windshrike     revised 7.11 shouda 
		for(Unit aiUnitOnBoard :gameState.getAiUnit()) {
			if(aiUnitOnBoard.getAttackChance()>0) {
				Random rand = new Random();
				int randomNum=rand.nextInt(2);
				if(aiUnitOnBoard.getId()==28) {
					if(randomNum==1) {
						gameState.flyToTile(aiUnitOnBoard, gameState.flyTileToMove(), out);
						gameState.clearFlyTile();
						aiUnitOnBoard.deleteAttackChance();
						aiUnitOnBoard.deleteMoveChance();	
					}else {
				
						gameState.attackthenflyToTile(aiUnitOnBoard,out,gameState.getHumanUnit());
						gameState.clearFlyTile();
						aiUnitOnBoard.deleteAttackChance();
						aiUnitOnBoard.deleteMoveChance();
					}
				}
			}

		}
		}
				
		//@XichunNing XiaoyuanChen	
		//Ai move & attack & provoke
		gameState.getAiUnit2().addAll(gameState.getAiUnit());
				for(Unit a : gameState.getAiUnit2()){
					
					if(gameState.getAvatar1().getHealth()<=0||!gameState.getAiUnit().contains(gameState.getAvatar2())) {            
					      break;
					     }	
					
					//judge if there are provoke unit
					if( (gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||
							(gameState.getSilverX()-a.getPosition().getTilex()==0&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||	
							(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||
							(gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==0)||	
							(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==0)||
							(gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==1)||	
							(gameState.getSilverX()-a.getPosition().getTilex()==0&&gameState.getSilverY()-a.getPosition().getTiley()==1)||
							(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==1)) {
			//cannot move	
					}
					
					
					else if( (gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==-1)||
							(gameState.getIronX()-a.getPosition().getTilex()==0&&gameState.getIronY()-a.getPosition().getTiley()==-1)||	
							(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==-1)||
							(gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==0)||	
							(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==0)||
							(gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==1)||	
							(gameState.getIronX()-a.getPosition().getTilex()==0&&gameState.getIronY()-a.getPosition().getTiley()==1)||
							(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==1)) {
			//cannot move			
					}
					
					else {
					
					//move range	
					if(a.getMoveChance()>0&&a.getAttackChance()>0) {
						int x = a.getPosition().getTilex();
						int y = a.getPosition().getTiley();
						
						int x1 = x-2;
						int x2 = x-1;
						int x3 = x;
						int x4 = x+1;
						int x5 = x+2;
						int y1 = y-2;
						int y2 = y-1;
						int y3 = y;
						int y4 = y+1;
						int y5 = y+2;


						if(x1<0) {
							x1=x5;
						}
						if(x2<0) {
							x1=x5;
							x2=x4;
						}
						if(x4>8) {
							x4=x2;
							x5=x1;
						}
						if(x5>8) {
							x5=x1;
						}
						if(y1<0) {
							y1=y5;
						}
						if(y2<0) {
							y1=y5;
							y2=y4;
						}
						if(y4>4) {
							y4=y2;
							y5=y1;
						}
						if(y5>4) {
							y5=y1;
						}
						

							gameState.getAiMoveTile().add(gameState.getAllTile()[x2][y2]);
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x3][y2])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x3][y2]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x4][y2])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x4][y2]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x2][y3])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x2][y3]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x4][y3])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x4][y3]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x2][y4])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x2][y4]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x3][y4])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x3][y4]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x4][y4])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x4][y4]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x3][y1])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x3][y1]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x3][y5])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x3][y5]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x5][y3])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x5][y3]);
							}
							if(!gameState.getAiMoveTile().contains(gameState.getAllTile()[x1][y3])) {
								gameState.getAiMoveTile().add(gameState.getAllTile()[x1][y3]);
							}							
							
							gameState.getAiMoveTile2().addAll(gameState.getAiMoveTile());
							for(Unit everyUnit : gameState.getAllUnit()) {
								int m = everyUnit.getPosition().getTilex();
								int n = everyUnit.getPosition().getTiley();
								for(Tile haveUnit : gameState.getAiMoveTile2()) {
									if(m==haveUnit.getTilex()&&n==haveUnit.getTiley()) {
										gameState.getAiMoveTile().remove(haveUnit);
									}
								}
							}	
							
							//attack range after moving 
							if(a.getMoveChance()>0&&a.getAttackChance()>0) {
								
								for(int g=0; g<gameState.getAiMoveTile().size();g++) {

								int p = gameState.getAiMoveTile().get(g).getTilex();
								int q = gameState.getAiMoveTile().get(g).getTiley();

									int p1 = p-1;
									int p2 = p;
									int p3 = p+1;						
									int q1 = q-1;
									int q2 = q;
									int q3 = q+1;
									if(p1<0) {
										p1=p3;
									}
									if(p3>8) {
										p3=p1;
									}
									if(q1<0) {
										q1=q3;
									}
									if(q3>4) {
										q3=q1;
									}
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p1][q2])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p1][q2]);
									}
		 
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p3][q2])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p3][q2]);
									}
									
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p2][q1])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p2][q1]);
									}
									
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p2][q3])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p2][q3]);
									}
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p1][q1])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p1][q1]);
									}
		 
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p1][q3])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p1][q3]);
									}
									
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p3][q1])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p3][q1]);
									}
									
									if(!gameState.getAiAttackCatchTile().contains(gameState.getAllTile()[p3][q3])) {
										gameState.getAiAttackCatchTile().add(gameState.getAllTile()[p3][q3]);
									}
									//judge if it can attack avatar
									for(Tile mayMoveTile : gameState.getAiAttackCatchTile()) {
										if(mayMoveTile.getTilex()==gameState.getHumanUnit().get(0).getPosition().getTilex()
												&&mayMoveTile.getTiley()==gameState.getHumanUnit().get(0).getPosition().getTiley()) {
											BasicCommands.moveUnitToTile(out, a, gameState.getAiMoveTile().get(g) );
											BasicCommands.playUnitAnimation(out, a, UnitAnimationType.move);
											a.setPositionByTile(gameState.getAiMoveTile().get(g)); 
											try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
											a.deleteMoveChance();											
											//attack										
											
											//attack Silverguard knight(provoke) around after moving
											if( (gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||
													(gameState.getSilverX()-a.getPosition().getTilex()==0&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||	
													(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==-1)||
													(gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==0)||	
													(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==0)||
													(gameState.getSilverX()-a.getPosition().getTilex()==-1&&gameState.getSilverY()-a.getPosition().getTiley()==1)||	
													(gameState.getSilverX()-a.getPosition().getTilex()==0&&gameState.getSilverY()-a.getPosition().getTiley()==1)||
													(gameState.getSilverX()-a.getPosition().getTilex()==1&&gameState.getSilverY()-a.getPosition().getTiley()==1)) {
												
												BasicCommands.playUnitAnimation(out, a, UnitAnimationType.attack);
												try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, a, UnitAnimationType.idle);
												a.deleteAttackChance();
												int remainHealthSilver = gameState.getSilver().getHealth() - a.getAttack();
												gameState.getSilver().setHealth(remainHealthSilver);
												BasicCommands.setUnitHealth(out, gameState.getSilver(), remainHealthSilver); 
																								
												if(gameState.getSilver().getHealth() <=0) {
													BasicCommands.playUnitAnimation(out, gameState.getSilver(), UnitAnimationType.death);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
													BasicCommands.deleteUnit(out, gameState.getSilver());
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												}
												else{
													BasicCommands.playUnitAnimation(out, gameState.getSilver(), UnitAnimationType.attack);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}	
													BasicCommands.playUnitAnimation(out, gameState.getSilver(), UnitAnimationType.idle);
													int remainHealthAi = a.getHealth() - gameState.getSilver().getAttack();
													a.setHealth(remainHealthAi);
													BasicCommands.setUnitHealth(out, a, remainHealthAi); 
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}													
													if(a.getHealth()<=0) {
													BasicCommands.playUnitAnimation(out, a, UnitAnimationType.death);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
													BasicCommands.deleteUnit(out, a);
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
													gameState.WindshrikeDie(a, out, gameState);
													gameState.getAiUnit().remove(a);
													gameState.getAllUnit().remove(a);
													}
												}
											}
											//attack Ironcliff guardian(provoke) around after moving
											else if( (gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==-1)||
													(gameState.getIronX()-a.getPosition().getTilex()==0&&gameState.getIronY()-a.getPosition().getTiley()==-1)||	
													(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==-1)||
													(gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==0)||	
													(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==0)||
													(gameState.getIronX()-a.getPosition().getTilex()==-1&&gameState.getIronY()-a.getPosition().getTiley()==1)||	
													(gameState.getIronX()-a.getPosition().getTilex()==0&&gameState.getIronY()-a.getPosition().getTiley()==1)||
													(gameState.getIronX()-a.getPosition().getTilex()==1&&gameState.getIronY()-a.getPosition().getTiley()==1)) {
												
												BasicCommands.playUnitAnimation(out, a, UnitAnimationType.attack);
												try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, a, UnitAnimationType.idle);
												a.deleteAttackChance();
												int remainHealthIron = gameState.getIron().getHealth() - a.getAttack();
												gameState.getIron().setHealth(remainHealthIron);
												BasicCommands.setUnitHealth(out, gameState.getIron(), remainHealthIron); 
											//calculate and counterattack													
												if(gameState.getIron().getHealth() <=0) {
													BasicCommands.playUnitAnimation(out, gameState.getIron(), UnitAnimationType.death);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
													BasicCommands.deleteUnit(out, gameState.getIron());
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												}
												else{
													BasicCommands.playUnitAnimation(out, gameState.getIron(), UnitAnimationType.attack);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}	
													BasicCommands.playUnitAnimation(out, gameState.getIron(), UnitAnimationType.idle);
													int remainHealthAi1 = a.getHealth() - gameState.getIron().getAttack();
													a.setHealth(remainHealthAi1);
													BasicCommands.setUnitHealth(out, a, remainHealthAi1); 
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}													
													if(a.getHealth()<=0) {
													BasicCommands.playUnitAnimation(out, a, UnitAnimationType.death);
													try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
													BasicCommands.deleteUnit(out, a);
													try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
													gameState.WindshrikeDie(a, out, gameState);
													gameState.getAiUnit().remove(a);
													gameState.getAllUnit().remove(a);
													}
												}																																						
											}
											
											else {
											//attack avatar if it could do
											BasicCommands.playUnitAnimation(out, a, UnitAnimationType.attack);
											try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
											BasicCommands.playUnitAnimation(out, a, UnitAnimationType.idle);
											a.deleteAttackChance();
											int remainHealthAvatar1 = gameState.getHumanUnit().get(0).getHealth() - a.getAttack();
											gameState.getHumanUnit().get(0).setHealth(remainHealthAvatar1);
											BasicCommands.setUnitHealth(out, gameState.getHumanUnit().get(0), remainHealthAvatar1); 
											//ability of Silverguard Knight
											for(Unit SilverKnight: gameState.getHumanUnit()) {
												if(SilverKnight.getId()==8) {
													int silverAddAttack2 = SilverKnight.getAttack()+2;
													SilverKnight.setAttack(silverAddAttack2);
													BasicCommands.setUnitAttack(out, SilverKnight, silverAddAttack2); 
													try {Thread.sleep(1000);} catch (InterruptedException e) {e.printStackTrace();}
													break;
												}
											}
											
											//calculate and counterattack
											if(gameState.getAvatar1().getHealth() <=0) {
												gameState.getHumanPlayer().setHealth(gameState.getAvatar1().getHealth());
												BasicCommands.setPlayer1Health(out,gameState.getHumanPlayer());
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, gameState.getAvatar1(), UnitAnimationType.death);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												
												gameState.avatarDead (gameState.getAvatar1(), out);
												gameState.avatarDead (a, out);
												BasicCommands.deleteUnit(out, gameState.getAvatar1());
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
											}
											else{
												BasicCommands.playUnitAnimation(out, gameState.getAvatar1(), UnitAnimationType.attack);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, gameState.getAvatar1(), UnitAnimationType.idle);
												
												int remainHealthAi = a.getHealth() - gameState.getHumanUnit().get(0).getAttack();
												a.setHealth(remainHealthAi);
												BasicCommands.setUnitHealth(out, a, remainHealthAi); 
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												
												if(a.getHealth()<=0) {
												BasicCommands.playUnitAnimation(out, a, UnitAnimationType.death);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.deleteUnit(out, a);
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												gameState.WindshrikeDie(a, out, gameState);
												gameState.getAiUnit().remove(a);
												gameState.getAllUnit().remove(a);
												}
											}
											}
											gameState.avatarDead (gameState.getAvatar1(), out);
											gameState.avatarDead (a, out);
										break;
									}
								}
							if(a.getMoveChance()==0) {
							break;
							}
					}
			}

							if(gameState.getAvatar1().getHealth()<=0||!gameState.getAiUnit().contains(gameState.getAvatar2())) {            
							      break;
							     }

							//move close to human avatar when cannot attack it
							int distance=Math.abs(x-gameState.getHumanUnit().get(0).getPosition().getTilex())
									+Math.abs(y-gameState.getHumanUnit().get(0).getPosition().getTiley());
							if(a.getMoveChance()>0&&a.getAttackChance()>0) {
									for(Tile canMoveTile:gameState.getAiMoveTile()) {
										if(( Math.abs(canMoveTile.getTilex()-gameState.getHumanUnit().get(0).getPosition().getTilex())
												+Math.abs(canMoveTile.getTiley()-gameState.getHumanUnit().get(0).getPosition().getTiley()) )<distance) 
										{
										distance=Math.abs(canMoveTile.getTilex()-gameState.getHumanUnit().get(0).getPosition().getTilex())
												+Math.abs(canMoveTile.getTiley()-gameState.getHumanUnit().get(0).getPosition().getTiley());
										gameState.getAiFinalMoveTile().clear();
										gameState.getAiFinalMoveTile().add(canMoveTile);
										}
									}									
									if(gameState.getAiFinalMoveTile().size()!=0) {																			
									BasicCommands.moveUnitToTile(out, a, gameState.getAiFinalMoveTile().get(0) );
									BasicCommands.playUnitAnimation(out, a, UnitAnimationType.move);
									a.setPositionByTile(gameState.getAiFinalMoveTile().get(0)); 
									try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
									a.deleteMoveChance();
									gameState.getAiFinalMoveTile().clear();
									}
								}													
								gameState.getAiMoveTile().clear();
								gameState.getAiAttackCatchTile().clear();					
						 }
					gameState.getHumanPlayer().setHealth(gameState.getHumanUnit().get(0).getHealth());
					BasicCommands.setPlayer1Health(out,gameState.getHumanPlayer());
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					gameState.getAiPlayer().setHealth(gameState.getAiUnit().get(0).getHealth());
					BasicCommands.setPlayer2Health(out,gameState.getAiPlayer());
					try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
					}
		}

				gameState.getAiUnit2().clear();
		
				gameState.getAiUnit2().addAll(gameState.getAiUnit());

				//@XichunNing XiaoyuanChen	
				//Ai attack other units when it cannot attack human avatar
				
				if(gameState.getAiUnit2().contains(gameState.getSerpenti())) {
					gameState.getAiUnit2().add(gameState.getSerpenti());
				}
				
				for(Unit cannotAttackAvatar:gameState.getAiUnit2()) {

					if(gameState.getAvatar1().getHealth()<=0||!gameState.getAiUnit().contains(gameState.getAvatar2())) {            
					      break;
					     }
					
					//provoke units around after moving
					if( (gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==-1)||
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==0&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==-1)||	
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==-1)||
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==0)||	
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==0)||
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==1)||	
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==0&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==1)||
							(gameState.getSilverX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getSilverY()-cannotAttackAvatar.getPosition().getTiley()==1)) {
							gameState.getHumanUnit2().add(gameState.getSilver());
					}
					else if( (gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==-1)||
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==0&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==-1)||	
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==-1)||
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==0)||	
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==0)||
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==-1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==1)||	
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==0&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==1)||
							(gameState.getIronX()-cannotAttackAvatar.getPosition().getTilex()==1&&gameState.getIronY()-cannotAttackAvatar.getPosition().getTiley()==1)) {
							gameState.getHumanUnit2().add(gameState.getIron());
					}
					
					else {
						//no provoke units around
					gameState.getHumanUnit2().addAll(gameState.getHumanUnit());
					}
					//get attack target
					int cannotAttackAvatarX=cannotAttackAvatar.getPosition().getTilex();
					int cannotAttackAvatarY=cannotAttackAvatar.getPosition().getTiley();
						for(Unit otherTarget:gameState.getHumanUnit2()) {
							if(cannotAttackAvatar.getAttackChance()>0) {
							int otherTX=otherTarget.getPosition().getTilex();
							int otherTY=otherTarget.getPosition().getTiley();
									int cannotAttackAvatarX1 = cannotAttackAvatarX-1;
									int cannotAttackAvatarX2 = cannotAttackAvatarX;
									int cannotAttackAvatarX3 = cannotAttackAvatarX+1;						
									int cannotAttackAvatarY1 = cannotAttackAvatarY-1;
									int cannotAttackAvatarY2 = cannotAttackAvatarY;
									int cannotAttackAvatarY3 = cannotAttackAvatarY+1;
									if(cannotAttackAvatarX1<0) {
										cannotAttackAvatarX1=cannotAttackAvatarX3;
									}
									if(cannotAttackAvatarX3>8) {
										cannotAttackAvatarX3=cannotAttackAvatarX1;
									}
									if(cannotAttackAvatarY1<0) {
										cannotAttackAvatarY1=cannotAttackAvatarY3;
									}
									if(cannotAttackAvatarY3>4) {
										cannotAttackAvatarY3=cannotAttackAvatarY1;
									}
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY2])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY2]);
									}
		 
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY2])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY2]);
									}
									
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX2][cannotAttackAvatarY1])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX2][cannotAttackAvatarY1]);
									}
									
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX2][cannotAttackAvatarY3])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX2][cannotAttackAvatarY3]);
									}
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY1])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY1]);
									}
		 
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY3])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX1][cannotAttackAvatarY3]);
									}
									
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY1])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY1]);
									}
									
									if(!gameState.getAiCanAttackTile().contains(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY3])) {
										gameState.getAiCanAttackTile().add(gameState.getAllTile()[cannotAttackAvatarX3][cannotAttackAvatarY3]);
									}
							//attack and calculate		
								for(Tile beAbleToAttack: gameState.getAiCanAttackTile()) {
									if(beAbleToAttack.getTilex()==otherTX&&beAbleToAttack.getTiley()==otherTY) {
									BasicCommands.playUnitAnimation(out, cannotAttackAvatar, UnitAnimationType.attack);											
									try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
									BasicCommands.playUnitAnimation(out, cannotAttackAvatar, UnitAnimationType.idle);
									cannotAttackAvatar.deleteAttackChance();
									int remainHealthOtherTarget = otherTarget.getHealth() - cannotAttackAvatar.getAttack();
									otherTarget.setHealth(remainHealthOtherTarget);
									BasicCommands.setUnitHealth(out, otherTarget, remainHealthOtherTarget); 
											
										//judge death
											if(otherTarget.getHealth() <=0) {
												gameState.getHumanPlayer().setHealth(gameState.getAvatar1().getHealth());
												BasicCommands.setPlayer1Health(out,gameState.getHumanPlayer());
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, otherTarget, UnitAnimationType.death);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.deleteUnit(out, otherTarget);
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												if(otherTarget!=gameState.getAvatar1()) {
												gameState.getHumanUnit().remove(otherTarget);
												gameState.getAllUnit().remove(otherTarget);
												}else {
													break;
												}
											}
										//counterattack
											else{
												BasicCommands.playUnitAnimation(out, otherTarget, UnitAnimationType.attack);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.playUnitAnimation(out, otherTarget, UnitAnimationType.idle);
												int remainHealthAiUnit = cannotAttackAvatar.getHealth() - otherTarget.getAttack();
												cannotAttackAvatar.setHealth(remainHealthAiUnit);
												BasicCommands.setUnitHealth(out, cannotAttackAvatar, remainHealthAiUnit); 
												
												if(cannotAttackAvatar.getHealth()<=0) {
												BasicCommands.playUnitAnimation(out, cannotAttackAvatar, UnitAnimationType.death);
												try {Thread.sleep(2000);} catch (InterruptedException e) {e.printStackTrace();}
												BasicCommands.deleteUnit(out, cannotAttackAvatar);
												try {Thread.sleep(30);} catch (InterruptedException e) {e.printStackTrace();}
												gameState.WindshrikeDie(cannotAttackAvatar, out, gameState);
												gameState.getAiUnit().remove(cannotAttackAvatar);
												gameState.getAllUnit().remove(cannotAttackAvatar);
												}
											}												
									gameState.getAiCanAttackTile().clear();		
									break;
										}
								}
								gameState.avatarDead (gameState.getAvatar1(), out);
								gameState.avatarDead (gameState.getAvatar2(), out);
						}		
				}
		gameState.getHumanUnit2().clear();				
	}		


				
		if(gameState.getGameEnd()!=1) {
		gameState.setTurn(gameState.getTurn()+1);	
		
		if(gameState.getAvatar1().getHealth()>0&&gameState.getAvatar2().getHealth()>0) {
		BasicCommands.addPlayer1Notification(out, "Turn  "+gameState.getTurn()+"",100);
		}
		
		
		
		//mana increment by turn
		if(gameState.getSumMana()<9) {
			gameState.getHumanPlayer().setMana(gameState.getTurn()+1);
			BasicCommands.setPlayer1Mana(out, gameState.getHumanPlayer());	
			gameState.getAiPlayer().setMana(gameState.getTurn()+1);
			BasicCommands.setPlayer2Mana(out, gameState.getAiPlayer());
			gameState.setSumMana(gameState.getTurn()+1);	
		}else{
			gameState.getHumanPlayer().setMana(9);
			BasicCommands.setPlayer1Mana(out, gameState.getHumanPlayer());	
			gameState.getAiPlayer().setMana(gameState.getTurn()+1);
			BasicCommands.setPlayer2Mana(out, gameState.getAiPlayer());
			gameState.setSumMana(9);	
			
		}
		

		if(gameState.getNumber1()<10) {
			if(gameState.getHumanHandCardNum()<6) {
				
	     BasicCommands.drawCard(out, gameState.drawHumanOneCard(gameState.getHumanCard()),
			gameState.getHumanHandCardNum(), 0);	
	 	try {Thread.sleep(500);} catch (InterruptedException e) {e.printStackTrace();}
			}else{
				gameState.surplusHandCard(gameState);
			}
			
		}
		
		// 7.2shouda
		if(gameState.getNumber2()<10) {
		if(gameState.getaiHandCardNum()<6) {	
					gameState.drawAiOneCard(gameState.getaiCard());
		}	else {
			gameState.surplusAIHandCard(gameState);
		}
			}
		
		}
		
		// the method of draw card by turn
	}else {
		if(gameState.getNumber1()>10||gameState.getHumanPlayer().getHealth()<=0) {
			BasicCommands.addPlayer1Notification(out, "Lost",100);
		}else {
			BasicCommands.addPlayer1Notification(out, "Win",100);
		}
	}	
		
		
	
		// reset hand card to avoid exceptions 
		for(int i=0;i<gameState.getHumanHandCard().size();i++) {
		BasicCommands.drawCard(out,gameState.getHumanHandCard().get(i), i+1, 0);
		gameState.clearSummonRange(out);
		}
		gameState.clearHightRed(out);
		
		
		
		//reset move and attack chance
		for(Unit a : gameState.getHumanUnit()) {
			a.replaceMoveChance();
		}
		for(Unit a : gameState.getHumanUnit()) {
			if(a.getId()==5) {
				a.lionAttackTwice();
			}else {
			a.replaceAttackChance();
			}
		}
		for(Unit a : gameState.getAiUnit()) {
			a.replaceMoveChance();
		}
		for(Unit a : gameState.getAiUnit()) {
			if(a.getId()==27) {
				a.lionAttackTwice();
			}else {
			a.replaceAttackChance();
			}
		}

		
	}

}
