
/* @author 
 * 2521509R
 * 2537942N
 * 2531726C
 * 2530845L
 * 2558276L
 */

package events;

import java.util.ArrayList;

import com.fasterxml.jackson.databind.JsonNode;

import akka.actor.ActorRef;
import commands.BasicCommands;
import structures.GameState;
import structures.basic.Card;

/**
 * Indicates that the user has clicked an object on the game canvas, in this
 * case a card. The event returns the position in the player's hand the card
 * resides within. 
 * 
 * { messageType = “cardClicked” position = <hand index position [1-6]> }
 * 
 * @author Dr. Richard McCreadie  ,SHOUDA REN 
 *
 */
public class CardClicked implements EventProcessor {

	@Override
	public void processEvent(ActorRef out, GameState gameState, JsonNode message) {

		gameState.clearMoveRange(out);
		gameState.clearAttackRange(out);

		int handPosition = message.get("position").asInt();
		int humanRecentMana = gameState.getHumanPlayer().getMana();
		// Record the position of the card I selected
		Card myChooselastCard = gameState.getWhichCardIchhose();
		int HumanHealth = gameState.getHumanPlayer().getHealth();
		int aiCardNumber = gameState.getNumber2();
		int HumanCardNumber = gameState.getNumber1();
		// hightmethod test
		// Check if the card can be used. If the mana cost of the card exceeds the mana of the player,
		// it cannot be lit, i.e. it cannot be generated

		
		
		  
		if (HumanCardNumber < 11 && aiCardNumber < 11 && gameState.getAiUnit().contains(gameState.getAvatar2())&& HumanHealth > 0) {
			 //The game is to stop
			if(HumanCardNumber==10) {
				  gameState.setNumber1(11);
			  }
			  if(aiCardNumber==10) {
				  gameState.setNumber2(11);
			  }
			
			//When the player clicks the card, it can only be used
			if (myChooselastCard != null) {
				gameState.clearMoveRange(out);
			}

			// when didn't have a choice on the last card
			if (myChooselastCard == null) {

				gameState.setWhichCardIchhose(gameState.getHumanHandCard().get(handPosition - 1));
				gameState.setWhichCardIchoosePosition(handPosition);

				int cardManaCost = gameState.getHumanHandCard().get(handPosition - 1).getManacost();

				if (cardManaCost <= humanRecentMana) {
					if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")
							|| gameState.getHumanHandCard().get(handPosition - 1).getCardname()
									.equals("Sundrop Elixir")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);

						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")) {
							gameState.showHightRed(out, gameState.getAiUnit());
						}
						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Sundrop Elixir")) {
							gameState.showHightRed(out, gameState.getAiUnit());
							gameState.showHightRed(out, gameState.getHumanUnit());
						}
					} else if (gameState.getHumanHandCard().get(handPosition - 1).getCardname()
							.equals("Ironcliff Guardian")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showAllemptyTile(out);
					}

					else {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showSummonRange(out, gameState.getHumanUnit());
					}
				}
				;
				// The last one stored was different from what I saved this time /6.27
			}

			if (myChooselastCard != null && gameState.getWhichCardIchhose()
					.equals(gameState.getHumanHandCard().get(handPosition - 1)) == false) {
				int cardManaCost = gameState.getHumanHandCard().get(handPosition - 1).getManacost();
				int position = gameState.getWhichCardIchoosePosition();
				gameState.clearSummonRange(out);
				gameState.clearHightRed(out);
				gameState.clearAllemptyTileHight(out);
				BasicCommands.drawCard(out, myChooselastCard, position, 0);
				if (cardManaCost <= humanRecentMana) {
					if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")
							|| gameState.getHumanHandCard().get(handPosition - 1).getCardname()
									.equals("Sundrop Elixir")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);

						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")) {
							gameState.showHightRed(out, gameState.getAiUnit());
						}
						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Sundrop Elixir")) {
							gameState.showHightRed(out, gameState.getAiUnit());
							gameState.showHightRed(out, gameState.getHumanUnit());
						}
					} else if (gameState.getHumanHandCard().get(handPosition - 1).getCardname()
							.equals("Ironcliff Guardian")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showAllemptyTile(out);
					}

					else {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showSummonRange(out, gameState.getHumanUnit());
					}

				}
				gameState.setWhichCardIchhose(gameState.getHumanHandCard().get(handPosition - 1));
				gameState.setWhichCardIchoosePosition(handPosition);

				// click the same card

			} else {

				int cardManaCost = gameState.getHumanHandCard().get(handPosition - 1).getManacost();

				if (cardManaCost <= humanRecentMana) {
					if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")
							|| gameState.getHumanHandCard().get(handPosition - 1).getCardname()
									.equals("Sundrop Elixir")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Truestrike")) {
							gameState.showHightRed(out, gameState.getAiUnit());
						}
						if (gameState.getHumanHandCard().get(handPosition - 1).getCardname().equals("Sundrop Elixir")) {
							gameState.showHightRed(out, gameState.getHumanUnit());
						}

					} else if (gameState.getHumanHandCard().get(handPosition - 1).getCardname()
							.equals("Ironcliff Guardian")) {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showAllemptyTile(out);
					}

					else {
						BasicCommands.drawCard(out, gameState.getHumanHandCard().get(handPosition - 1), handPosition,
								1);
						gameState.showSummonRange(out, gameState.getHumanUnit());
					}
				}
			}

		}else {
			if(HumanCardNumber>10||HumanHealth <=0) {
				BasicCommands.addPlayer1Notification(out, "Lost",100);
			}else {
				BasicCommands.addPlayer1Notification(out, "Win",100);
			}
		}

	}

}


