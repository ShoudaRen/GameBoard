package utils;

import com.fasterxml.jackson.databind.node.ObjectNode;

import events.CardClicked;
import play.libs.Json;
import structures.GameState;
class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test test = new Test();
		test.testEndturn();

	}
	
	
	public void testEndturn() {
		GameState gamestate = new GameState();
		CardClicked  cjeck = new  CardClicked();
		ObjectNode  evenMessage = Json.newObject();
		
		 cjeck.processEvent(null, gamestate, evenMessage);
	}

}
